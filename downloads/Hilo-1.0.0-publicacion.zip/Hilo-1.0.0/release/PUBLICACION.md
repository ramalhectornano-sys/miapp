# Entrega de Hilo 1.0.0 para Google Play

## Qué está terminado

App Android completa, trece actividades, ruta de siete prácticas, niveles y progreso local; contacto público y política accesible dentro de Ajustes; banner adaptable abajo con consentimiento UMP y acceso a opciones de privacidad cuando corresponde; anuncios ocultos en prácticas, ajustes y menú; ficha, icono, gráfico y capturas de la tienda; sitio de soporte/privacidad con app-ads.txt; construcción de producción con IDs reales y configuración de firma por clave del propietario.

IDs reales:

- App: ca-app-pub-4739373930169128~6642682897
- Banner: ca-app-pub-4739373930169128/7981007269

## Archivos de entrega

- APK de prueba: instalable en Android, misma firma que las versiones anteriores, usa anuncios de demostración. No genera ingresos ni es un paquete para subir a Play.
- `Hilo-1.0.0-produccion-sin-firmar.aab`: paquete de producción con los IDs reales. **Está sin firmar y Google Play no lo aceptará así.** No se generó una clave de publicación sin que el propietario pudiera conservarla.
- `Hilo-1.0.0-publicacion.zip`: fuentes de la app, proyecto Android y estos materiales. No contiene contraseñas, claves de firma, caches ni dependencias instaladas.

## Pasos exclusivos del propietario

1. Crear la cuenta de Google Play Console con su identidad y pagar la tarifa que Google muestre. La app puede ser gratis para sus usuarios; publicar requiere una cuenta de desarrollador. Completar las verificaciones del titular y dispositivo que solicite Google.
2. Conservar una clave de carga propia. Los APK demo usan otra firma: la versión de Play no actualizará esa instalación de prueba y puede requerir desinstalarla, perdiendo su progreso local. En Android Studio, abrir el proyecto Android desde las fuentes preparadas y usar Build → Generate Signed Bundle / APK → Android App Bundle. Crear o seleccionar el keystore de carga, respaldarlo con sus contraseñas fuera del repositorio, y habilitar Play App Signing. No usar Android Debug como firma de producción. Si ya existe una app con este paquete, debe usarse su clave o la ruta de restablecimiento autorizada por Play.
3. Publicar `site/` en hosting HTTPS. La política tiene que estar accesible sin registro; el desarrollador es Ramal Hector Ruben, ramalhector.nano@gmail.com. Para AdMob, `app-ads.txt` debe estar en **la raíz del dominio que aparece como sitio web del desarrollador**, no solamente dentro de una subcarpeta. Un sitio GitHub Pages de proyecto `/miapp/` sirve para la política pero no garantiza la verificación del archivo en la raíz del dominio. Configurar las URLs confirmadas en `src/data/publisher.ts` y reconstruir antes de subir.
4. En AdMob, registrar/enlazar la app de Google Play, verificar la propiedad por app-ads.txt, configurar y publicar los mensajes de privacidad de UMP según las regiones habilitadas, completar revisión de la app y datos de pagos. Poner IDs en el código no activa por sí solo anuncios ni ingresos. No pulsar anuncios propios para probarlos; usar el APK demo o un dispositivo de prueba configurado en Google para la validación.
5. Crear la ficha con `FICHA-GOOGLE-PLAY.md` y las imágenes de `store/`. Marcar que contiene anuncios, completar Seguridad de los datos y clasificación de contenido con la aplicación final y el SDK instalado. Elegir el público real de la app; esta entrega no configura publicidad infantil ni certifica cumplimiento de programas para familias. No declarar un público infantil sin adaptar primero anuncios y privacidad.
6. Revisar la declaración de aplicaciones de salud de Play con el contenido real: la app incluye respiración y recursos para expresión y bienestar, aunque se presenta como educativa y no realiza diagnósticos o tratamientos. No asumir que la categoría Educación exime esa declaración.
7. Subir el AAB firmado a una prueba interna. En un teléfono Android comprobar inicio, prácticas, progreso tras actualizar, borrado, funcionamiento sin conexión, SDK/consentimiento, banner sin tapar controles y preferencias de anuncios. Esta entrega verificó compilación y pruebas de navegador/mocks; no validó anuncios reales en un teléfono.
8. Completar las pruebas cerradas y solicitar acceso a producción si la cuenta nueva lo requiere. Play Console muestra los requisitos vigentes de participantes y duración. Enviar a revisión únicamente cuando esas verificaciones hayan pasado. No se puede garantizar la aprobación ni ingresos.

## Firma automatizada opcional

`npm run android:release` produce el borrador de AAB de producción.

`npm run android:publish` exige las URLs públicas de `publisher.ts` y estas variables, suministradas de forma privada, sin escribir valores en el repositorio:

- HILO_UPLOAD_STORE_FILE: ruta al keystore del propietario.
- HILO_UPLOAD_STORE_PASSWORD
- HILO_UPLOAD_KEY_ALIAS
- HILO_UPLOAD_KEY_PASSWORD

El comando verifica que haya firma y rechaza el certificado Android Debug. No sube el paquete ni cambia las cuentas de Google.

## Seguridad de los datos: revisión asistida

El historial, favoritos, puntos y valoraciones de Hilo permanecen en el dispositivo. Las respuestas de ejercicios no persisten. No hay cuenta, micrófono, cámara, ubicación precisa, contactos, SDK de Firebase Analytics ni Crashlytics. No hay formulario de datos bancarios reales; el ejercicio de dinero usa un caso ficticio.

Google Mobile Ads 25.4.0 y UMP 4.0.0 están incluidos. Revisar las instrucciones oficiales vigentes del SDK para declarar sus datos: IP/posible ubicación aproximada, identificadores de dispositivo o publicidad, interacción con anuncios y diagnósticos/rendimiento pueden transmitirse. Finalidades incluyen publicidad/medición, análisis y prevención de fraude. La recopilación y opciones dependen de la configuración y región. Eliminar progreso local no elimina datos recibidos por Google. La ficha no debe decir «no recopila datos» ni «todo se queda en el dispositivo» sin explicar la publicidad.

## Fuentes oficiales para el titular

- Cuenta y requisitos: https://play.google.com/console/signup
- Requisitos de pruebas de cuentas personales: https://support.google.com/googleplay/android-developer/answer/14151465
- API objetivo: https://support.google.com/googleplay/android-developer/answer/11926878
- Play App Signing: https://support.google.com/googleplay/android-developer/answer/9842756
- Declaración de datos de Google Mobile Ads: https://developers.google.com/admob/android/privacy/play-data-disclosure
- UMP Android: https://developers.google.com/admob/android/privacy
- app-ads.txt: https://support.google.com/admob/answer/9363762
- Política de privacidad de Google: https://policies.google.com/privacy

Estas páginas deben revisarse en las consolas antes de enviar: el entorno no pudo consultar sus versiones actuales por la restricción de red. El paquete apunta a Android API 36; confirmar que Play lo acepte para la fecha de envío.
