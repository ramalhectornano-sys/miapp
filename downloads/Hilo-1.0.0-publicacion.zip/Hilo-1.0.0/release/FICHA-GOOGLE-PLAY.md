# Hilo: ficha lista para copiar en Google Play

Nombre (máximo 30 caracteres): **Hilo: ideas a tu ritmo**

Descripción breve (máximo 80 caracteres):

> Practicá cómo expresarte, ordenar ideas y pensar con claridad, a tu ritmo.

Descripción completa:

Hilo te propone un espacio para practicar cómo ordenar tus ideas y expresarlas con tus propias palabras. Gratis, sin registro y con actividades breves para hacer a tu ritmo.

Una idea a la vez
Construí una oración con quién, acción y detalle. Practicá explicar un punto de vista con una razón y un ejemplo, o contar algo cotidiano sin buscar palabras perfectas.

Herramientas para pensar y conversar
Separá hechos de suposiciones, considerá otras explicaciones, ensayá cómo expresar una necesidad y practicá escuchar antes de responder. También hay casos ficticios para comparar compras y convertir una decisión pequeña en un plan.

Una ruta de siete prácticas
Cada actividad nueva incluye una situación, una guía, un ejemplo, un ensayo a tu manera, puntos de revisión y un paso para aplicar en tu día. Unos cinco minutos sugeridos; podés repetir, pausar, saltar o elegir otro orden.

Tu progreso, sin presión
Los puntos, niveles e historial reconocen la práctica realizada. Si querés, podés valorar tu percepción de claridad antes y después de ensayar la misma situación. Es una comparación personal; no una evaluación clínica ni una medición automática de tu voz.

Memoria y palabras que acompañan
Leé fragmentos de dominio público de Machado y Cervantes, intentá recordarlos y guardá tus favoritos. En Biblioteca encontrarás referencias de los recursos de comunicación y aprendizaje usados como inspiración.

Privacidad
No grabamos audio ni pedimos micrófono, cámara, contactos o ubicación precisa. Tus respuestas no se guardan ni se envían. El progreso se guarda en este dispositivo y podés borrarlo desde Ajustes. No hay cuentas ni sincronización.

Hilo se sostiene con un banner de Google AdMob, que se oculta durante las prácticas. El SDK de publicidad puede procesar datos del dispositivo, de anuncios y de diagnóstico conforme a las preferencias y políticas de Google. Hay acceso a la política de privacidad y a opciones de anuncios cuando Google las requiere.

Hilo ofrece recursos educativos. No realiza diagnósticos ni reemplaza atención psicológica o fonoaudiológica, y no ofrece asesoramiento financiero personalizado ni garantiza resultados. No hace falta hacerlo perfecto: podés empezar por una idea.

Categoría propuesta: Educación. Aplicación gratuita; marcar que contiene anuncios. No hay compras ni suscripciones. Sin acceso restringido ni credenciales de revisión.

Responsable: Ramal Hector Ruben
Correo público de soporte: ramalhector.nano@gmail.com
Paquete: com.ramalhectornano.hilo
Versión inicial de tienda: 1.0.0 (código 3)

## Recursos

- `store/icon-512.png`: icono 512 × 512.
- `store/feature-1024x500.png`: gráfico 1024 × 500.
- `store/01-inicio.png` a `05-biblioteca.png`: cinco capturas de la interfaz móvil, 1080 × 1920. Capturas reales, sin progreso ni anuncios inventados; no se fotografió un dispositivo físico.
- `site/`: sitio de soporte, política de privacidad y declaración app-ads.txt, listo para hosting HTTPS.

No poner una URL local, un archivo descargable o una página privada como política de privacidad. Publicar `site/privacy.html` en un sitio público HTTPS sin inicio de sesión. No declarar que no se recopilan datos: AdMob sí puede transmitir datos fuera del dispositivo.
