import { publisher, privacySections } from '../data/publisher';

export default function PrivacyInformation() {
  return <section className="privacy-information" aria-labelledby="privacy-information-title">
    <details>
      <summary id="privacy-information-title">Política de privacidad y contacto</summary>
      <p>Actualizada: {publisher.policyUpdated} · Hilo</p>
      {privacySections.map(section => <div key={section.title}><h3>{section.title}</h3><p>{section.text}</p></div>)}
      <p><a href={`mailto:${publisher.email}`}>Contactar a {publisher.name}</a></p>
      {publisher.privacyPolicyUrl && <p><a href={publisher.privacyPolicyUrl} target="_blank" rel="noreferrer">Ver política publicada ↗</a></p>}
      <p><a href="https://policies.google.com/privacy" target="_blank" rel="noreferrer">Política de privacidad de Google ↗</a></p>
      <p><a href="https://myadcenter.google.com/" target="_blank" rel="noreferrer">Opciones de publicidad de Google ↗</a></p>
    </details>
  </section>;
}
