import { useEffect, useId, useMemo, useRef, useState } from 'react';
import type { KeyboardEvent } from 'react';
import { exercises, type Exercise } from '../data/exercises';
import { training } from '../data/training';
import GuidedPractice, { emptyGuidedDraft, guidedReady, type GuidedDraft } from './GuidedPractice';
import type { ClarityAssessment } from '../lib/progress';

type PracticeResult = {
  exerciseIds: string[];
  durationSeconds: number;
  xp: number;
  assessments?: ClarityAssessment[];
};

type Props = {
  exerciseIds: string[];
  mode: 'session' | 'exercise';
  quote?: { text: string; author: string; book: string };
  onClose: () => void;
  onComplete: (result: PracticeResult) => void;
};

type Draft = {
  idea: string;
  detail: string;
  closing: string;
  recall: string;
  memoryHidden: boolean;
  memoryCompared: boolean;
  story: string;
  connector: string;
  connected: string;
  reflection: string;
  breathSeconds: number;
  manualPause: boolean;
  guided?: GuidedDraft;
};

const emptyDraft: Draft = {
  idea: '', detail: '', closing: '', recall: '', memoryHidden: false,
  memoryCompared: false, story: '', connector: 'porque',
  connected: '', reflection: '', breathSeconds: 0, manualPause: false,
};

const memoryQuote = 'Caminante, no hay camino,\nse hace camino al andar.';

function spokenDraft(idea: string, detail: string, closing: string) {
  const first = idea.trim();
  const second = detail.trim();
  const last = closing.trim();
  const parts: string[] = [];
  const connective = /^(porque|pues|ya que|para|por eso|aunque)\b/iu.exec(second);
  if (first && second && connective && !/[?!]["'”»)]*$/u.test(first)) {
    const word = connective[1].toLocaleLowerCase('es');
    const separator = word === 'porque' || word === 'para' ? ' ' : ', ';
    parts.push(first.replace(/[.,;:…]+$/u, '') + separator + word + second.slice(connective[1].length));
  } else {
    if (first) parts.push(first);
    if (second) parts.push(second);
  }
  if (last) parts.push(last);
  return parts.map((part) => {
    const capitalized = part.replace(/\p{L}/u, (letter) => letter.toLocaleUpperCase('es'));
    return /[.!?…]["'”»)]*$/u.test(capitalized) ? capitalized : capitalized + '.';
  }).join(' ');
}

function Glyph({ icon }: { icon: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      {icon === 'layers' && <><path d="m12 3 9 5-9 5-9-5 9-5Z" /><path d="m3 12 9 5 9-5M3 16l9 5 9-5" /></>}
      {icon === 'spark' && <><path d="m12 3 2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5L12 3Z" /></>}
      {icon === 'leaf' && <><path d="M20 4c-8-1-15 3-15 9a6 6 0 0 0 6 6c6 0 10-7 9-15Z" /><path d="m4 21 11-11" /></>}
      {icon === 'chat' && <><path d="M21 11.5a8.5 8.5 0 0 1-8.5 8.5H4l-1 2v-9.5a8.5 8.5 0 1 1 18-1Z" /><path d="M8 9h8M8 13h5" /></>}
      {icon === 'link' && <><path d="m10 13 4-4M8.5 15.5l-1 1a4 4 0 0 1-6-6l4-4a4 4 0 0 1 6 0M15.5 8.5l1-1a4 4 0 0 1 6 6l-4 4a4 4 0 0 1-6 0" /></>}
      {icon === 'book' && <><path d="M12 5c-3-2-7-2-10-1v15c3-1 7-1 10 1 3-2 7-2 10-1V4c-3-1-7-1-10 1ZM12 5v15" /></>}
    </svg>
  );
}

function isReady(exercise: Exercise | undefined, draft: Draft) {
  switch (exercise?.id) {
    case 'ordena': return [draft.idea, draft.detail, draft.closing].every((value) => value.trim().length >= 3);
    case 'recuerda': return draft.recall.trim().length >= 8 && draft.memoryCompared;
    case 'pausa': return draft.breathSeconds >= 60 || draft.manualPause;
    case 'historia': return draft.story.trim().length >= 20;
    case 'conecta': return draft.connected.trim().length >= 12 && draft.connected.toLocaleLowerCase().includes(draft.connector);
    case 'lectura': return draft.reflection.trim().length >= 12;
    default: {
      const guidedExercise = training.find(item => item.id === exercise?.id);
      return Boolean(guidedExercise && guidedReady(draft.guided ?? emptyGuidedDraft, guidedExercise));
    }
  }
}

const guidance: Record<string, string> = {
  ordena: 'Completá la idea, el detalle y el cierre para seguir. Unas pocas palabras alcanzan.',
  recuerda: 'Escribí unas palabras de lo que recordás y compará la frase para seguir.',
  pausa: 'Podés seguir después del minuto guiado o marcar que hiciste una pausa a tu ritmo.',
  historia: 'Contá ese pequeño momento en una frase para seguir.',
  conecta: 'Escribí una frase que incluya el conector que elegiste.',
  lectura: 'Escribí una frase con tu propia interpretación para seguir.',
};

export default function PracticeModal({ exerciseIds, mode, quote, onClose, onComplete }: Props) {
  const selected = useMemo(() => [...new Set(exerciseIds)].flatMap((id) => {
    const exercise = exercises.find((item) => item.id === id);
    return exercise ? [exercise] : [];
  }), [exerciseIds]);
  const [step, setStep] = useState(0);
  const [drafts, setDrafts] = useState<Record<string, Draft>>({});
  const [completed, setCompleted] = useState<string[]>([]);
  const [skipped, setSkipped] = useState<string[]>([]);
  const [dirty, setDirty] = useState(false);
  const [confirmClose, setConfirmClose] = useState(false);
  const [breathing, setBreathing] = useState(false);
  const [summaryDuration, setSummaryDuration] = useState(0);
  const startedAt = useRef(Date.now());
  const committed = useRef(false);
  const dialogRef = useRef<HTMLDivElement>(null);
  const headingRef = useRef<HTMLHeadingElement>(null);
  const returnButtonRef = useRef<HTMLButtonElement>(null);
  const memoryInputRef = useRef<HTMLTextAreaElement>(null);
  const breathSecondsRef = useRef(0);
  const uid = useId();
  const exercise = selected[step];
  const guidedExercise = training.find(item => item.id === exercise?.id);
  const draft = drafts[exercise?.id ?? ''] ?? emptyDraft;
  const isSummary = step >= selected.length;
  const ready = isReady(exercise, draft);
  const totalXp = completed.reduce((sum, id) => sum + (exercises.find((item) => item.id === id)?.xp ?? 0), 0);
  const breathPhase = draft.breathSeconds % 10 < 4 ? 'inhale' : 'exhale';
  breathSecondsRef.current = draft.breathSeconds;

  useEffect(() => {
    const previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = previousOverflow;
      previousFocus?.focus();
    };
  }, []);

  useEffect(() => {
    if (confirmClose) returnButtonRef.current?.focus();
    else headingRef.current?.focus();
  }, [step, confirmClose]);

  useEffect(() => {
    if (exercise?.id === 'recuerda' && draft.memoryHidden && !confirmClose) memoryInputRef.current?.focus();
  }, [exercise?.id, draft.memoryHidden, confirmClose]);

  useEffect(() => {
    if (!breathing || exercise?.id !== 'pausa') return;
    const start = Date.now();
    const baseSeconds = breathSecondsRef.current;
    const interval = window.setInterval(() => {
      const seconds = Math.min(60, baseSeconds + Math.floor((Date.now() - start) / 1000));
      setDrafts((previous) => (previous.pausa?.breathSeconds === seconds ? previous : {
        ...previous, pausa: { ...(previous.pausa ?? emptyDraft), breathSeconds: seconds },
      }));
      if (seconds >= 60) setBreathing(false);
    }, 250);
    return () => window.clearInterval(interval);
  }, [breathing, exercise?.id]);

  function updateDraft(patch: Partial<Draft>) {
    if (!exercise) return;
    setDirty(true);
    setDrafts((previous) => ({ ...previous, [exercise.id]: { ...(previous[exercise.id] ?? emptyDraft), ...patch } }));
  }

  function requestClose() {
    if (dirty && !committed.current) {
      setBreathing(false);
      setConfirmClose(true);
    } else onClose();
  }

  function handleKeyDown(event: KeyboardEvent<HTMLDivElement>) {
    if (event.key === 'Escape') {
      event.preventDefault();
      if (confirmClose) setConfirmClose(false);
      else requestClose();
    }
    if (event.key !== 'Tab') return;
    const focusable = Array.from(dialogRef.current?.querySelectorAll<HTMLElement>(
      'button:not([disabled]), a[href], summary, input:not([disabled]), textarea:not([disabled]), select:not([disabled]), [tabindex="0"]',
    ) ?? []).filter((element) => element.getClientRects().length > 0);
    const first = focusable[0];
    const last = focusable[focusable.length - 1];
    if (!first || !last) {
      event.preventDefault();
      dialogRef.current?.focus();
    } else if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  }

  function next(skip = false) {
    if (!exercise || (!skip && !ready)) return;
    setDirty(true);
    setBreathing(false);
    if (skip) setSkipped((previous) => [...previous, exercise.id]);
    else setCompleted((previous) => [...previous, exercise.id]);
    if (step === selected.length - 1) setSummaryDuration(Math.max(1, Math.round((Date.now() - startedAt.current) / 1000)));
    setStep((previous) => previous + 1);
  }

  function saveProgress() {
    if (committed.current) return;
    committed.current = true;
    const assessments = completed.flatMap(exerciseId => {
      const value = drafts[exerciseId]?.guided;
      return value?.before && value.after ? [{ exerciseId, before: value.before, after: value.after }] : [];
    });
    onComplete({ exerciseIds: completed, durationSeconds: summaryDuration, xp: totalXp, assessments });
  }

  function fieldId(name: string) { return `${uid}-${name}`; }

  return (
    <div className="practice-overlay" onMouseDown={(event) => { if (event.target === event.currentTarget) requestClose(); }}>
      <div className="practice-modal" role="dialog" aria-modal="true" aria-labelledby={`${uid}-title`} ref={dialogRef} tabIndex={-1} onKeyDown={handleKeyDown}>
        <header className="practice-header">
          <div className="practice-heading">
            <span className="practice-eyebrow">UN MOMENTO PARA VOS</span>
            <h2 id={`${uid}-title`}>{mode === 'session' ? 'Tu práctica de hoy' : 'Vamos a practicar'}</h2>
          </div>
          <button className="practice-close" onClick={requestClose} aria-label="Cerrar práctica">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" aria-hidden="true"><path d="m6 6 12 12M18 6 6 18" /></svg>
          </button>
        </header>

        {!confirmClose && selected.length > 1 && (
          <div className="practice-progress" aria-label={isSummary ? 'Práctica terminada' : `Ejercicio ${step + 1} de ${selected.length}`}>
            {selected.map((item, index) => <span key={item.id} className={`practice-progress-step${index < step ? ' is-complete' : ''}${index === step ? ' is-active' : ''}`} />)}
          </div>
        )}

        <div className="practice-body">
          {confirmClose ? (
            <div className="practice-confirm">
              <span className="practice-eyebrow">PODÉS VOLVER CUANDO QUIERAS</span>
              <h3>¿Querés dejar esta práctica?</h3>
              <p>Si salís ahora, no se guardará el avance de esta práctica y tus respuestas se borrarán.</p>
              <div className="practice-actions">
                <button ref={returnButtonRef} className="practice-button practice-button--primary" onClick={() => setConfirmClose(false)}>Seguir practicando</button>
                <button className="practice-button practice-button--secondary" onClick={onClose}>Salir de la práctica</button>
              </div>
            </div>
          ) : isSummary ? (
            <div className="practice-summary">
              <div className="practice-summary-mark" aria-hidden="true">✦</div>
              <span className="practice-eyebrow">A TU RITMO, UN PASO MÁS</span>
              <h3 ref={headingRef} tabIndex={-1}>{completed.length ? 'Te diste un espacio para practicar' : 'Hoy también podés ir despacio'}</h3>
              <p>{completed.length ? 'Cada intento cuenta. No hace falta encontrar las palabras perfectas.' : 'Podés volver a estas actividades cuando te venga bien.'}</p>
              <div className="practice-stats">
                <div className="practice-stat"><strong>{completed.length}<small> / {selected.length}</small></strong><span>actividades</span></div>
                <div className="practice-stat"><strong>+{totalXp}</strong><span>XP ganados</span></div>
                <div className="practice-stat"><strong>{Math.floor(summaryDuration / 60)}:{String(summaryDuration % 60).padStart(2, '0')}</strong><span>tiempo de práctica</span></div>
              </div>
              <div className="practice-completed-list">
                {selected.map((item) => <div className="practice-result" key={item.id}><span>{item.title}</span><span>{completed.includes(item.id) ? `+${item.xp} XP` : 'Para otro momento'}</span></div>)}
              </div>
              {skipped.length > 0 && <p className="practice-helper">Las actividades que saltaste no suman XP. Podés retomarlas cuando quieras.</p>}
              {completed.some(id => training.some(item => item.id === id)) && <div className="guided-motivation">{completed.flatMap(id => {
                const item = training.find(entry => entry.id === id);
                return item ? [<p key={id}>{item.motivation}</p>] : [];
              })}<p>La próxima vez, repetí la estructura con menos apoyo si te resulta cómodo.</p></div>}
              <button className="practice-button practice-button--primary" onClick={saveProgress}>{completed.length ? 'Guardar mi avance' : 'Volver al inicio'}</button>
              <p className="practice-helper">{completed.length ? 'El avance se guarda en este dispositivo. Tus respuestas no se guardan.' : 'No se guardará una práctica sin actividades completadas.'}</p>
            </div>
          ) : exercise && (
            <>
              <div className="practice-intro">
                <span className={`practice-title-icon practice-title-icon--${exercise.color}`}><Glyph icon={exercise.icon} /></span>
                <span className="practice-chip">{exercise.category} · {(exercise.duration / 60).toLocaleString('es', { maximumFractionDigits: 1 })} min sugeridos</span>
                <h3 ref={headingRef} tabIndex={-1}>{exercise.title}</h3>
                <p className="practice-description">{exercise.description}</p>
              </div>

              {exercise.id === 'ordena' && (
                <>
                  <div className="practice-fields">
                    <div className="practice-field"><label htmlFor={fieldId('idea')}>1. ¿Qué querés contar?</label><input id={fieldId('idea')} className="practice-input" placeholder="Me gustaría aprender algo nuevo…" value={draft.idea} onChange={(event) => updateDraft({ idea: event.target.value })} maxLength={300} /></div>
                    <div className="practice-field"><label htmlFor={fieldId('detail')}>2. Sumá un detalle o una razón</label><input id={fieldId('detail')} className="practice-input" placeholder="Porque disfruto descubrir cosas…" value={draft.detail} onChange={(event) => updateDraft({ detail: event.target.value })} maxLength={300} /></div>
                    <div className="practice-field"><label htmlFor={fieldId('closing')}>3. ¿Con qué idea querés cerrar?</label><input id={fieldId('closing')} className="practice-input" placeholder="Voy a empezar con algo pequeño…" value={draft.closing} onChange={(event) => updateDraft({ closing: event.target.value })} maxLength={300} /></div>
                  </div>
                  <div className="practice-preview"><span className="practice-preview-label">ASÍ VA TOMANDO FORMA</span><p>{spokenDraft(draft.idea, draft.detail, draft.closing) || 'Tu idea aparecerá acá, una parte a la vez.'}</p></div>
                  <p className="practice-tip">Ahora probá decirla en voz alta, haciendo una pequeña pausa entre cada parte. Si preferís, recorré las palabras en silencio.</p>
                </>
              )}

              {exercise.id === 'recuerda' && (
                <>
                  {(!draft.memoryHidden || draft.memoryCompared) && <blockquote className="practice-quote"><p>{quote?.text ?? memoryQuote}</p><footer className="practice-attribution">{quote?.author ?? 'Antonio Machado'} · <cite>{quote?.book ?? 'Proverbios y cantares, XXIX'}</cite></footer></blockquote>}
                  {!draft.memoryHidden && <><p className="practice-tip">Leé la frase despacio, una o dos veces. Después ocultala e intentá recuperar lo que te quedó.</p><button className="practice-button practice-button--secondary" onClick={() => updateDraft({ memoryHidden: true, memoryCompared: false })}>Ya la leí, ocultar frase</button></>}
                  {draft.memoryHidden && <div className="practice-fields"><div className="practice-field"><label htmlFor={fieldId('recall')}>¿Qué palabras recordás?</label><textarea ref={memoryInputRef} id={fieldId('recall')} className="practice-textarea" placeholder="Escribí lo que te quedó, aunque no sea igual…" value={draft.recall} maxLength={1000} onChange={(event) => updateDraft({ recall: event.target.value, memoryCompared: false })} rows={3} /></div><button className="practice-button practice-button--secondary" disabled={draft.recall.trim().length < 8} onClick={() => updateDraft({ memoryCompared: true })}>{draft.memoryCompared ? 'Frase a la vista' : 'Comparar con la frase'}</button></div>}
                  {draft.memoryCompared && <p className="practice-tip">Miralas juntas, sin ponerte una nota. ¿Qué palabra volvió primero? Podés decir tu versión en voz alta.</p>}
                </>
              )}

              {exercise.id === 'pausa' && (
                <>
                  <p className="practice-tip">Si te resulta cómodo, acompañá el círculo: 4 segundos al inhalar y 6 al exhalar. Respirá sin forzar; podés pausar o seguir a tu propio ritmo.</p>
                  <div className="practice-breath">
                    <div className={`practice-breath-circle${breathing ? ' is-running' : ''}`} data-phase={breathPhase}>
                      <span className="practice-breath-word" aria-live="polite">{draft.breathSeconds >= 60 ? 'Bien ahí' : breathing ? (breathPhase === 'inhale' ? 'Inhalá' : 'Exhalá') : 'A tu ritmo'}</span>
                      <span className="practice-breath-time">{draft.breathSeconds >= 60 ? 'Pausa completada' : `${60 - draft.breathSeconds} segundos`}</span>
                    </div>
                  </div>
                  {draft.breathSeconds < 60 && <button className="practice-button practice-button--secondary" onClick={() => { setDirty(true); setBreathing((previous) => !previous); }}>{breathing ? 'Pausar respiración' : draft.breathSeconds > 0 ? 'Continuar respiración' : 'Empezar respiración'}</button>}
                  <label className="practice-checkbox" htmlFor={fieldId('manual-pause')}><input id={fieldId('manual-pause')} type="checkbox" checked={draft.manualPause} onChange={(event) => { updateDraft({ manualPause: event.target.checked }); setBreathing(false); }} /><span>Hice una pausa a mi ritmo</span></label>
                </>
              )}

              {exercise.id === 'historia' && (
                <>
                  <div className="practice-preview"><span className="practice-preview-label">UN PUNTO DE PARTIDA</span><p>Contá un pequeño momento de hoy: qué pasó, cómo te sentiste y qué vino después.</p></div>
                  <div className="practice-field"><label htmlFor={fieldId('story')}>Tu historia, con tus palabras</label><textarea id={fieldId('story')} className="practice-textarea" placeholder="Hoy, mientras preparaba el desayuno…" value={draft.story} onChange={(event) => updateDraft({ story: event.target.value })} maxLength={2000} rows={5} /></div>
                  <p className="practice-tip">Probá contarla en voz alta como si hablaras con alguien de confianza. Podés apoyarte en «primero», «después» y «al final».</p>
                </>
              )}

              {exercise.id === 'conecta' && (
                <>
                  <div className="practice-field"><label htmlFor={fieldId('connector')}>Elegí una palabra puente</label><select id={fieldId('connector')} className="practice-input" value={draft.connector} onChange={(event) => updateDraft({ connector: event.target.value })}><option value="porque">porque · para dar una razón</option><option value="además">además · para sumar algo</option><option value="aunque">aunque · para contrastar</option><option value="por eso">por eso · para mostrar una consecuencia</option></select></div>
                  <div className="practice-field"><label htmlFor={fieldId('connected')}>Escribí una frase que incluya «{draft.connector}»</label><textarea id={fieldId('connected')} className="practice-textarea" placeholder="Me gusta caminar porque me ayuda a ver cosas nuevas…" value={draft.connected} onChange={(event) => updateDraft({ connected: event.target.value })} maxLength={1000} rows={3} /></div>
                  <p className="practice-tip">Decí la frase en voz alta. Hacé una pausa justo antes de «{draft.connector}» y escuchá cómo se unen tus ideas.</p>
                </>
              )}

              {exercise.id === 'lectura' && (
                <>
                  <blockquote className="practice-quote"><p>{quote?.text ?? '«Todo pasa y todo queda,\npero lo nuestro es pasar,\npasar haciendo caminos,\ncaminos sobre la mar.»'}</p><footer className="practice-attribution">{quote?.author ?? 'Antonio Machado'} · <cite>{quote?.book ?? 'Proverbios y cantares, XLIV'}</cite></footer></blockquote>
                  <div className="practice-field"><label htmlFor={fieldId('reflection')}>¿Qué significa esta frase para vos?</label><textarea id={fieldId('reflection')} className="practice-textarea" placeholder="A mí me hace pensar en…" value={draft.reflection} onChange={(event) => updateDraft({ reflection: event.target.value })} maxLength={1500} rows={4} /></div>
                  <p className="practice-tip">No hay una única interpretación. Decí la tuya en voz alta como si se la explicaras a alguien que no leyó la frase.</p>
                </>
              )}

              {guidedExercise && <GuidedPractice key={exercise.id} exercise={guidedExercise} draft={draft.guided ?? emptyGuidedDraft} onChange={guided => updateDraft({ guided })} />}

              <div className="practice-actions">
                <button className="practice-button practice-button--primary" disabled={!ready} onClick={() => next()}>{step < selected.length - 1 ? 'Siguiente ejercicio' : 'Ver mi avance'}<span aria-hidden="true"> →</span></button>
                <button className="practice-button practice-button--quiet" onClick={() => next(true)}>Saltar por ahora</button>
              </div>
              <p className="practice-helper" aria-live="polite">{ready ? 'Listo para seguir, cuando vos quieras.' : guidance[exercise.id] ?? 'Completá las tres partes, ensayá y revisá los tres puntos para seguir. Las valoraciones y el reloj son opcionales.'}</p>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
