import { ArrowRight, Check, MessageCircle } from 'lucide-react';
import { getTrainingProgress, type Progress } from '../lib/progress';

export default function TrainingRoute({ progress, onStart }: { progress: Progress; onStart: (id: string) => void }) {
  const route = getTrainingProgress(progress);
  return <section className="training-route" aria-labelledby="training-title">
    <div className="section-heading"><div><span className="eyebrow">HERRAMIENTAS PARA EL DÍA A DÍA</span><h2 id="training-title">Pensá, ordená, expresá</h2><p>7 prácticas de unos 5 minutos. Una por día si te sirve; repetí o elegí el orden que quieras.</p></div><span className="week-badge">{route.completedCount}/7</span></div>
    <div className="training-method"><MessageCircle size={24} /><p><strong>Un sistema para practicar:</strong> pensá una primera respuesta, ordenala con la guía, ensayá, revisá y llevá un paso a tu día. Los tiempos son sugeridos.</p></div>
    <ol className="training-steps">{route.items.map((item, index) => <li key={item.id}>
      <button onClick={() => onStart(item.id)} className={item.completed ? 'is-complete' : ''}>
        <span className="training-step-number">{item.completed ? <Check size={16} aria-label="Practicado" /> : index + 1}</span>
        <span><small>{item.category}</small><strong>{item.title}</strong><small>{item.count ? `${item.count} ${item.count === 1 ? 'práctica guardada' : 'prácticas guardadas'} · Podés repetir` : '5 min sugeridos · Con ejemplo y revisión'}</small></span>
        <ArrowRight size={17} />
      </button>
    </li>)}</ol>
    <button className="button button-primary" onClick={() => onStart(route.nextId)}>{route.completedCount === 7 ? 'Volver a practicar la ruta' : route.completedCount ? 'Continuar mi ruta' : 'Empezar mi ruta'}<ArrowRight size={17} /></button>
    <p className="muted-note">No hay días perdidos ni ejercicios bloqueados. Los puntos reconocen tu práctica; no miden inteligencia ni salud mental.</p>
  </section>;
}

export function SkillsProgress({ progress, onStart }: { progress: Progress; onStart: (id: string) => void }) {
  const route = getTrainingProgress(progress);
  const first = route.clarity[0];
  const last = route.clarity.at(-1);
  const difference = first && last ? last.after - first.before : undefined;
  return <section className="skills-progress" aria-labelledby="skills-title">
    <div className="section-heading"><div><h2 id="skills-title">Lo que estás practicando</h2><p>{route.completedCount} de 7 herramientas exploradas. Una marca significa que hiciste la práctica, no que dominás la habilidad.</p></div></div>
    <div className="skill-tags">{route.items.map(item => <span key={item.id} className={item.completed ? 'is-complete' : ''}>{item.completed && <Check size={13} />}{item.title}<small>{item.count}</small></span>)}</div>
    <div className="clarity-card"><span className="eyebrow">TU PERCEPCIÓN DE CLARIDAD</span><h3>La misma situación, distintos intentos</h3>
      <p>En «De palabras a una oración» repetís la propuesta de una caminata. Valorá cómo sentís tu explicación antes y después de ensayar. No se analiza tu voz ni se califica tu respuesta.</p>
      {first && last ? <>
        <div className="clarity-comparison"><div><strong>{first.before}/5</strong><span>Antes del primer intento</span></div><ArrowRight size={20} /><div><strong>{last.after}/5</strong><span>Después del último ensayo</span></div></div>
        <p>{route.clarity.length} {route.clarity.length === 1 ? 'práctica con valoración' : 'prácticas con valoración'}. {difference! > 0 ? 'En el último ensayo percibiste más claridad que antes del primer intento.' : difference === 0 ? 'La valoración coincide. Volver a practicar también cuenta.' : 'La última valoración es menor. Puede variar según el día; no borra tu práctica.'} Es una comparación personal, no una prueba de mejora causada por la app.</p>
        <ol className="clarity-history">{route.clarity.slice(-5).map((item, index) => <li key={`${item.date}-${index}`}><span>{new Intl.DateTimeFormat('es', { day: 'numeric', month: 'short' }).format(new Date(item.date))}</span><span>Antes {item.before}/5 → Después {item.after}/5</span></li>)}</ol>
      </> : <p className="muted-note">Todavía no hay valoraciones. Son opcionales: elegí ambas en esta práctica para empezar tu comparación.</p>}
      <button className="text-button" onClick={() => onStart('oracion')}>Repetir la misma situación<ArrowRight size={16} /></button>
    </div>
  </section>;
}
