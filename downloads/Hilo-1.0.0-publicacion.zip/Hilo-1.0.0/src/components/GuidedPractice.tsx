import { useEffect, useId, useState } from 'react';
import type { GuidedExercise } from '../data/training';

export type GuidedDraft = {
  answers: string[];
  checks: boolean[];
  before?: number;
  after?: number;
  rehearsed: boolean;
};

export const emptyGuidedDraft: GuidedDraft = { answers: [], checks: [], rehearsed: false };

export function guidedReady(draft: GuidedDraft, exercise: GuidedExercise) {
  return exercise.fields.every((_, index) => (draft.answers[index] ?? '').trim().length >= 3)
    && exercise.review.every((_, index) => draft.checks[index] === true)
    && draft.rehearsed;
}

function Rating({ label, value, onChange }: { label: string; value?: number; onChange: (value?: number) => void }) {
  const id = useId();
  return <div className="practice-field rating-field"><label htmlFor={id}>{label}</label>
    <select id={id} value={value ?? ''} onChange={e => onChange(e.target.value ? Number(e.target.value) : undefined)}>
      <option value="">Prefiero no valorar</option>
      <option value="1">1 · Me cuesta mucho ordenar la idea</option>
      <option value="2">2 · Necesito bastante apoyo</option>
      <option value="3">3 · Puedo explicarla con algunas pausas</option>
      <option value="4">4 · La explico con bastante claridad</option>
      <option value="5">5 · La explico con mucha claridad</option>
    </select>
  </div>;
}

export default function GuidedPractice({ exercise, draft, onChange }: {
  exercise: GuidedExercise;
  draft: GuidedDraft;
  onChange: (draft: GuidedDraft) => void;
}) {
  const uid = useId();
  const [running, setRunning] = useState(false);
  const [seconds, setSeconds] = useState(0);
  useEffect(() => {
    if (!running) return;
    const started = Date.now();
    const base = seconds;
    const timer = window.setInterval(() => {
      const next = Math.min(60, base + Math.floor((Date.now() - started) / 1000));
      setSeconds(next);
      if (next === 60) setRunning(false);
    }, 250);
    return () => window.clearInterval(timer);
    // Restart only when the timer is resumed; retain elapsed time while paused.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [running]);
  const patch = (value: Partial<GuidedDraft>) => onChange({ ...draft, ...value });
  return <div className="guided-practice">
    <div className="practice-preview"><span className="practice-preview-label">1 · UN CASO PARA PRACTICAR</span><p>{exercise.situation}</p></div>
    <Rating label="Antes de escribir: ¿qué tan clara sentís tu explicación? (opcional)" value={draft.before} onChange={before => patch({ before })} />
    <p className="practice-helper">Pensá una primera respuesta. Si querés comparar, valorala antes de usar la guía. La escala describe tu percepción, no evalúa tu capacidad.</p>
    <div className="practice-fields">
      {exercise.fields.map((field, index) => <div className="practice-field" key={field.label}>
        <label htmlFor={`${uid}-${index}`}>{index + 1}. {field.label}</label>
        <textarea id={`${uid}-${index}`} className="practice-textarea" rows={2} maxLength={800} placeholder={field.hint}
          value={draft.answers[index] ?? ''} onChange={e => {
            const answers = [...draft.answers]; answers[index] = e.target.value;
            patch({ answers, checks: [], rehearsed: false, after: undefined });
          }} />
      </div>)}
    </div>
    <details className="guided-example"><summary>Ver un ejemplo y comparar</summary><p>{exercise.example}</p><p>No tenés que copiarlo. Revisá qué recurso podrías usar en tu versión.</p></details>
    <div className="practice-preview"><span className="practice-preview-label">2 · ENSAYÁ TU EXPLICACIÓN</span><p>{draft.answers.filter(Boolean).join(' ') || 'Tu explicación se irá formando acá.'}</p></div>
    <p className="practice-tip">Decila en voz alta con pausas. También podés escribirla o recorrerla en silencio. Revisá una parte y probá de nuevo. No se graba audio.</p>
    <div className="rehearsal-timer"><span aria-label="Tiempo de ensayo">{Math.floor(seconds / 60)}:{String(seconds % 60).padStart(2, '0')}</span>
      <button className="practice-button practice-button--secondary" onClick={() => { if (seconds >= 60) setSeconds(0); setRunning(!running); }}>{running ? 'Pausar ensayo' : seconds >= 60 ? 'Repetir minuto de ensayo' : 'Ensayar con un minuto opcional'}</button>
    </div>
    <label className="practice-checkbox"><input type="checkbox" checked={draft.rehearsed} onChange={e => patch({ rehearsed: e.target.checked })} /><span>Ensayé mi explicación, en voz alta o a mi manera</span></label>
    <fieldset className="guided-review"><legend>3 · Revisá tu versión y ajustá lo que haga falta</legend>
      {exercise.review.map((text, index) => <label className="practice-checkbox" key={text}><input type="checkbox" checked={draft.checks[index] ?? false} onChange={e => {
        const checks = [...draft.checks]; checks[index] = e.target.checked; patch({ checks });
      }} /><span>{text}</span></label>)}
    </fieldset>
    <Rating label="Después del ensayo: ¿qué tan clara sentís tu explicación? (opcional)" value={draft.after} onChange={after => patch({ after })} />
    <p className="practice-helper">Usá la misma escala. Si hoy te cuesta más, no perdiste progreso. Solo se guardan los números si elegís ambas valoraciones, nunca tus respuestas.</p>
    <div className="practice-tip"><strong>Un paso para hoy</strong><p>{exercise.transfer}</p></div>
  </div>;
}
