import { useCallback, useLayoutEffect, useRef, useState } from 'react'
import { Capacitor } from '@capacitor/core'
import { AdMob } from '@capacitor-community/admob'
import { createBannerController, createSerialExecutor, initialBannerState } from './bannerController'
import { getBannerOptions, supportsNativeAds } from './config'

const nativeExecutor = createSerialExecutor()

function setBannerHeight(height: number) {
  document.documentElement.style.setProperty('--admob-banner-height', `${height}px`)
}

export default function useAdMobBanner(blocked: boolean) {
  const isNativeAndroid = supportsNativeAds(Capacitor)
  const [state, setState] = useState(() => initialBannerState(isNativeAndroid))
  const controller = useRef<ReturnType<typeof createBannerController> | null>(null)
  const initialBlocked = useRef(blocked)

  useLayoutEffect(() => {
    const next = createBannerController({
      sdk: AdMob,
      isNativeAndroid,
      blocked: initialBlocked.current,
      bannerOptions: getBannerOptions(import.meta.env.VITE_ADMOB_LIVE_ADS),
      onState: setState,
      setBannerHeight,
      executor: nativeExecutor,
    })
    controller.current = next
    void next.start()
    return () => {
      controller.current = null
      void next.dispose()
    }
  }, [isNativeAndroid])

  useLayoutEffect(() => {
    void controller.current?.setBlocked(blocked)
  }, [blocked])

  const openPrivacyOptions = useCallback(async () => {
    await controller.current?.openPrivacyOptions()
  }, [])

  return { ...state, openPrivacyOptions }
}
