import { describe, expect, it, vi } from 'vitest'
import { AdmobConsentStatus, BannerAdPluginEvents } from '@capacitor-community/admob'
import type { AdmobConsentInfo } from '@capacitor-community/admob'
import { adsMessages, createBannerController, createSerialExecutor } from './bannerController'
import type { BannerState } from './bannerController'
import { getBannerOptions, LIVE_BANNER_ID, supportsNativeAds, TEST_BANNER_ID } from './config'

function privacyStatus(value: 'REQUIRED' | 'NOT_REQUIRED'): AdmobConsentInfo['privacyOptionsRequirementStatus'] {
  return value as AdmobConsentInfo['privacyOptionsRequirementStatus']
}

function consent(overrides: Partial<AdmobConsentInfo> = {}): AdmobConsentInfo {
  return {
    status: AdmobConsentStatus.NOT_REQUIRED,
    canRequestAds: true,
    isConsentFormAvailable: false,
    privacyOptionsRequirementStatus: privacyStatus('NOT_REQUIRED'),
    ...overrides,
  }
}

function deferred<T>() {
  let resolve!: (value: T | PromiseLike<T>) => void
  let reject!: (reason?: unknown) => void
  const promise = new Promise<T>((yes, no) => { resolve = yes; reject = no })
  return { promise, resolve, reject }
}

function mockSdk(initialConsent = consent()) {
  const callbacks = new Map<BannerAdPluginEvents, (payload?: unknown) => void>()
  const removers: ReturnType<typeof vi.fn>[] = []
  const order: string[] = []
  const emit = (event: BannerAdPluginEvents, payload?: unknown) => callbacks.get(event)?.(payload)
  const sdk = {
    requestConsentInfo: vi.fn(async () => { order.push('consent'); return initialConsent }),
    showConsentForm: vi.fn(async () => { order.push('consent-form'); return consent({ status: AdmobConsentStatus.OBTAINED }) }),
    showPrivacyOptionsForm: vi.fn(async () => { order.push('privacy-form') }),
    initialize: vi.fn(async () => { order.push('initialize') }),
    addListener: vi.fn(async (event: BannerAdPluginEvents, callback: unknown) => {
      order.push(event)
      callbacks.set(event, callback as (payload?: unknown) => void)
      const remove = vi.fn(async () => { callbacks.delete(event) })
      removers.push(remove)
      return { remove }
    }),
    showBanner: vi.fn(async () => {
      order.push('show')
      emit(BannerAdPluginEvents.SizeChanged, { width: 360, height: 64 })
      emit(BannerAdPluginEvents.Loaded)
    }),
    hideBanner: vi.fn(async () => { order.push('hide'); emit(BannerAdPluginEvents.SizeChanged, { width: 0, height: 0 }) }),
    resumeBanner: vi.fn(async () => {
      order.push('resume')
      emit(BannerAdPluginEvents.SizeChanged, { width: 360, height: 64 })
    }),
    removeBanner: vi.fn(async () => { order.push('remove'); emit(BannerAdPluginEvents.SizeChanged, { width: 0, height: 0 }) }),
  }
  return { sdk, emit, order, removers }
}

function setup(options: { native?: boolean; blocked?: boolean; live?: string; consent?: AdmobConsentInfo; executor?: ReturnType<typeof createSerialExecutor> } = {}) {
  const mock = mockSdk(options.consent)
  const states: BannerState[] = []
  const height = vi.fn<(height: number) => void>()
  const executor = options.executor ?? createSerialExecutor()
  const controller = createBannerController({
    sdk: mock.sdk,
    isNativeAndroid: options.native ?? true,
    blocked: options.blocked ?? false,
    bannerOptions: getBannerOptions(options.live),
    onState: state => states.push(state),
    setBannerHeight: height,
    executor,
  })
  return { ...mock, controller, states, height, executor }
}

describe('AdMob configuration', () => {
  it.each([
    [false, 'web', false],
    [false, 'android', false],
    [true, 'ios', false],
    [true, 'android', true],
  ])('permits the hook SDK only on native Android (native=%s, platform=%s)', (native, platform, allowed) => {
    expect(supportsNativeAds({ isNativePlatform: () => native, getPlatform: () => platform })).toBe(allowed)
  })

  it.each([undefined, '', 'false', 'TRUE', '1'])('uses Google test ads without an explicit live opt-in (%s)', value => {
    expect(getBannerOptions(value)).toEqual({
      adId: TEST_BANNER_ID,
      isTesting: true,
      adSize: 'ADAPTIVE_BANNER',
      position: 'BOTTOM_CENTER',
      margin: 0,
    })
  })

  it('uses the supplied publisher unit only after an explicit opt-in', () => {
    expect(getBannerOptions('true')).toMatchObject({ adId: LIVE_BANNER_ID, isTesting: false })
  })
})

describe('native banner lifecycle', () => {
  it('does not invoke any SDK method on the web, including privacy and teardown', async () => {
    const { controller, sdk, height } = setup({ native: false })
    await controller.start()
    await controller.setBlocked(true)
    await controller.setBlocked(false)
    await controller.openPrivacyOptions()
    await controller.dispose()
    for (const method of Object.values(sdk)) expect(method).not.toHaveBeenCalled()
    expect(height.mock.calls.every(([value]) => value === 0)).toBe(true)
  })

  it('updates UMP consent before initialization and subscribes before showing a banner', async () => {
    const { controller, sdk, order, states, height } = setup({ consent: consent({ status: AdmobConsentStatus.REQUIRED, isConsentFormAvailable: true, canRequestAds: false }) })
    await controller.start()
    expect(order).toEqual([
      'consent', 'consent-form', 'initialize',
      BannerAdPluginEvents.SizeChanged, BannerAdPluginEvents.Loaded, BannerAdPluginEvents.FailedToLoad, 'show',
    ])
    expect(sdk.initialize).toHaveBeenCalledWith({ initializeForTesting: true })
    expect(sdk.showBanner).toHaveBeenCalledWith(getBannerOptions(undefined))
    expect(states.at(-1)).toMatchObject({ adsStatus: adsMessages.test, isPrivacyBusy: false })
    expect(height).toHaveBeenLastCalledWith(64)
    await controller.dispose()
  })

  it('does not initialize or request ads when the consent form does not permit requests', async () => {
    const { controller, sdk, states, height } = setup({ consent: consent({ status: AdmobConsentStatus.REQUIRED, isConsentFormAvailable: true, canRequestAds: false }) })
    sdk.showConsentForm.mockResolvedValue(consent({ status: AdmobConsentStatus.REQUIRED, canRequestAds: false }))
    await controller.start()
    expect(sdk.showConsentForm).toHaveBeenCalledOnce()
    expect(sdk.initialize).not.toHaveBeenCalled()
    expect(sdk.addListener).not.toHaveBeenCalled()
    expect(sdk.showBanner).not.toHaveBeenCalled()
    expect(states.at(-1)?.adsStatus).toBe(adsMessages.denied)
    expect(height).toHaveBeenLastCalledWith(0)
    await controller.dispose()
  })

  it('does not show an unavailable form or treat an unknown consent status as permission', async () => {
    const { controller, sdk } = setup({ consent: consent({ status: AdmobConsentStatus.UNKNOWN, canRequestAds: false }) })
    await controller.start()
    expect(sdk.showConsentForm).not.toHaveBeenCalled()
    expect(sdk.initialize).not.toHaveBeenCalled()
    await controller.dispose()
  })

  it('uses live banner settings only after opting in', async () => {
    const { controller, sdk, states } = setup({ live: 'true' })
    await controller.start()
    expect(sdk.initialize).toHaveBeenCalledWith({ initializeForTesting: false })
    expect(sdk.showBanner).toHaveBeenCalledWith(getBannerOptions('true'))
    expect(states.at(-1)?.adsStatus).toBe(adsMessages.live)
    await controller.dispose()
  })

  it('reserves the measured logical height and clears it on failure without retry loops', async () => {
    const { controller, sdk, emit, height, states, executor } = setup()
    await controller.start()
    emit(BannerAdPluginEvents.SizeChanged, { height: 91.5, width: 800 })
    expect(height).toHaveBeenLastCalledWith(91.5)
    emit(BannerAdPluginEvents.SizeChanged, { height: NaN, width: 800 })
    expect(height).toHaveBeenLastCalledWith(0)
    emit(BannerAdPluginEvents.FailedToLoad, { code: 3, message: 'No fill' })
    emit(BannerAdPluginEvents.Loaded)
    await controller.setBlocked(true)
    await controller.setBlocked(false)
    await executor.run(async () => undefined)
    expect(height).toHaveBeenLastCalledWith(0)
    expect(states.at(-1)?.adsStatus).toBe(adsMessages.unavailable)
    expect(sdk.showBanner).toHaveBeenCalledOnce()
    expect(sdk.hideBanner).not.toHaveBeenCalled()
    expect(sdk.resumeBanner).not.toHaveBeenCalled()
    await controller.dispose()
  })

  it('defers the first banner while a dialog is open without hiding a nonexistent ad', async () => {
    const { controller, sdk, height } = setup({ blocked: true })
    await controller.start()
    expect(sdk.showBanner).not.toHaveBeenCalled()
    expect(sdk.hideBanner).not.toHaveBeenCalled()
    expect(height).toHaveBeenLastCalledWith(0)
    await controller.setBlocked(false)
    expect(sdk.showBanner).toHaveBeenCalledOnce()
    expect(height).toHaveBeenLastCalledWith(64)
    await controller.dispose()
  })

  it('hides around exercises and resumes the existing banner after closing', async () => {
    const { controller, sdk, emit, height, executor, states } = setup()
    await controller.start()
    const hiding = controller.setBlocked(true)
    expect(height).toHaveBeenLastCalledWith(0)
    await hiding
    expect(sdk.hideBanner).toHaveBeenCalledOnce()
    emit(BannerAdPluginEvents.SizeChanged, { width: 360, height: 64 })
    emit(BannerAdPluginEvents.Loaded)
    await executor.run(async () => undefined)
    expect(height).toHaveBeenLastCalledWith(0)
    expect(sdk.resumeBanner).not.toHaveBeenCalled()
    await controller.setBlocked(false)
    expect(sdk.resumeBanner).toHaveBeenCalledOnce()
    expect(sdk.showBanner).toHaveBeenCalledOnce()
    expect(height).toHaveBeenLastCalledWith(64)
    expect(states.at(-1)?.adsStatus).toBe(adsMessages.test)
    await controller.dispose()
  })

  it('hides an in-flight banner as soon as its show operation resolves after a dialog opens', async () => {
    const { controller, sdk, emit, height } = setup()
    const show = deferred<void>()
    sdk.showBanner.mockImplementation(() => show.promise)
    const starting = controller.start()
    await vi.waitFor(() => expect(sdk.showBanner).toHaveBeenCalledOnce())
    const blocking = controller.setBlocked(true)
    emit(BannerAdPluginEvents.SizeChanged, { width: 360, height: 64 })
    emit(BannerAdPluginEvents.Loaded)
    expect(height).toHaveBeenLastCalledWith(0)
    show.resolve(undefined)
    await starting
    await blocking
    expect(sdk.hideBanner).toHaveBeenCalledOnce()
    expect(sdk.resumeBanner).not.toHaveBeenCalled()
    await controller.dispose()
  })

  it('does not initialize or show late ads when teardown happens during consent lookup', async () => {
    const { controller, sdk, states, height } = setup()
    const result = deferred<AdmobConsentInfo>()
    sdk.requestConsentInfo.mockImplementation(() => result.promise)
    const starting = controller.start()
    await vi.waitFor(() => expect(sdk.requestConsentInfo).toHaveBeenCalledOnce())
    const disposing = controller.dispose()
    result.resolve(consent())
    await starting
    await disposing
    expect(sdk.initialize).not.toHaveBeenCalled()
    expect(sdk.showBanner).not.toHaveBeenCalled()
    expect(states).toEqual([])
    expect(height).toHaveBeenLastCalledWith(0)
  })

  it('cleans up a late native show and all individual subscriptions after unmount', async () => {
    const { controller, sdk, emit, states, height, removers } = setup()
    const show = deferred<void>()
    sdk.showBanner.mockImplementation(() => show.promise)
    const starting = controller.start()
    await vi.waitFor(() => expect(sdk.showBanner).toHaveBeenCalledOnce())
    const countBeforeDispose = states.length
    const disposing = controller.dispose()
    emit(BannerAdPluginEvents.Loaded)
    emit(BannerAdPluginEvents.SizeChanged, { width: 360, height: 64 })
    show.resolve(undefined)
    await starting
    await disposing
    expect(sdk.removeBanner).toHaveBeenCalledOnce()
    expect(removers).toHaveLength(3)
    for (const remove of removers) expect(remove).toHaveBeenCalledOnce()
    expect(states).toHaveLength(countBeforeDispose)
    expect(height).toHaveBeenLastCalledWith(0)
  })

  it('serializes a StrictMode remount behind cleanup of the previous native banner', async () => {
    const executor = createSerialExecutor()
    const first = setup({ executor })
    const second = setup({ executor })
    const show = deferred<void>()
    first.sdk.showBanner.mockImplementation(() => show.promise)
    const starting = first.controller.start()
    await vi.waitFor(() => expect(first.sdk.showBanner).toHaveBeenCalledOnce())
    const disposing = first.controller.dispose()
    const restarting = second.controller.start()
    expect(second.sdk.requestConsentInfo).not.toHaveBeenCalled()
    show.resolve(undefined)
    await starting
    await disposing
    await restarting
    expect(first.sdk.removeBanner).toHaveBeenCalledOnce()
    expect(second.sdk.showBanner).toHaveBeenCalledOnce()
    expect(first.sdk.removeBanner.mock.invocationCallOrder[0]).toBeLessThan(second.sdk.showBanner.mock.invocationCallOrder[0])
    await second.controller.dispose()
  })

  it('fails closed on consent or initialization errors and leaves practice usable', async () => {
    const { controller, sdk, states, height } = setup()
    sdk.requestConsentInfo.mockRejectedValue(new Error('UMP unavailable'))
    await controller.start()
    expect(sdk.initialize).not.toHaveBeenCalled()
    expect(sdk.showBanner).not.toHaveBeenCalled()
    expect(states.at(-1)).toMatchObject({ adsStatus: adsMessages.unavailable, isPrivacyBusy: false })
    expect(height).toHaveBeenLastCalledWith(0)
    await controller.dispose()

    const other = setup()
    other.sdk.initialize.mockRejectedValue(new Error('SDK initialization unavailable'))
    await other.controller.start()
    expect(other.sdk.showBanner).not.toHaveBeenCalled()
    expect(other.states.at(-1)?.adsStatus).toBe(adsMessages.unavailable)
    await other.controller.dispose()
  })

  it('removes a partially created view if showing fails', async () => {
    const { controller, sdk, states, height } = setup()
    sdk.showBanner.mockRejectedValue(new Error('Native view unavailable'))
    await controller.start()
    expect(sdk.removeBanner).toHaveBeenCalledOnce()
    expect(states.at(-1)?.adsStatus).toBe(adsMessages.unavailable)
    expect(height).toHaveBeenLastCalledWith(0)
    await controller.setBlocked(true)
    await controller.setBlocked(false)
    expect(sdk.showBanner).toHaveBeenCalledOnce()
    await controller.dispose()
  })
})

describe('privacy options', () => {
  const privacyRequired = consent({ privacyOptionsRequirementStatus: privacyStatus('REQUIRED') })

  it('removes the old banner before the privacy form and honors revoked consent', async () => {
    const { controller, sdk, states, height, order } = setup({ consent: privacyRequired })
    await controller.start()
    expect(states.at(-1)?.privacyOptionsRequired).toBe(true)
    sdk.requestConsentInfo.mockResolvedValue(consent({ canRequestAds: false, privacyOptionsRequirementStatus: privacyStatus('REQUIRED') }))
    const updating = controller.openPrivacyOptions()
    expect(states.at(-1)?.isPrivacyBusy).toBe(true)
    expect(height).toHaveBeenLastCalledWith(0)
    await updating
    expect(order.slice(-2)).toEqual(['remove', 'privacy-form'])
    expect(sdk.requestConsentInfo).toHaveBeenCalledTimes(2)
    expect(sdk.showPrivacyOptionsForm.mock.invocationCallOrder[0]).toBeLessThan(sdk.requestConsentInfo.mock.invocationCallOrder[1])
    expect(states.at(-1)).toMatchObject({ adsStatus: adsMessages.denied, isPrivacyBusy: false })
    await controller.setBlocked(true)
    await controller.setBlocked(false)
    expect(sdk.showBanner).toHaveBeenCalledOnce()
    expect(sdk.resumeBanner).not.toHaveBeenCalled()
    await controller.dispose()
  })

  it('initializes later if updated preferences permit ads, while respecting the open settings dialog', async () => {
    const { controller, sdk, states } = setup({ blocked: true, consent: consent({ ...privacyRequired, canRequestAds: false }) })
    await controller.start()
    expect(sdk.initialize).not.toHaveBeenCalled()
    sdk.requestConsentInfo.mockResolvedValue(privacyRequired)
    await controller.openPrivacyOptions()
    expect(sdk.initialize).toHaveBeenCalledOnce()
    expect(states.at(-1)?.isPrivacyBusy).toBe(false)
    expect(sdk.showBanner).not.toHaveBeenCalled()
    await controller.setBlocked(false)
    expect(sdk.showBanner).toHaveBeenCalledOnce()
    await controller.dispose()
  })

  it('prevents duplicate privacy forms and late ads while the form is open', async () => {
    const { controller, sdk, emit, height, states } = setup({ consent: privacyRequired })
    await controller.start()
    const form = deferred<void>()
    sdk.showPrivacyOptionsForm.mockImplementation(() => form.promise)
    const changing = controller.openPrivacyOptions()
    await vi.waitFor(() => expect(sdk.showPrivacyOptionsForm).toHaveBeenCalledOnce())
    await controller.openPrivacyOptions()
    emit(BannerAdPluginEvents.Loaded)
    emit(BannerAdPluginEvents.SizeChanged, { width: 360, height: 64 })
    expect(height).toHaveBeenLastCalledWith(0)
    expect(states.at(-1)?.isPrivacyBusy).toBe(true)
    form.resolve(undefined)
    await changing
    expect(sdk.showPrivacyOptionsForm).toHaveBeenCalledOnce()
    expect(sdk.showBanner).toHaveBeenCalledTimes(2)
    await controller.dispose()
  })

  it('does not open privacy options if UMP does not require the entry point', async () => {
    const { controller, sdk, states } = setup()
    await controller.start()
    await controller.openPrivacyOptions()
    expect(states.at(-1)?.privacyOptionsRequired).toBe(false)
    expect(sdk.showPrivacyOptionsForm).not.toHaveBeenCalled()
    await controller.dispose()
  })

  it('keeps the banner removed if privacy refresh fails and permits another explicit attempt', async () => {
    const { controller, sdk, states, height } = setup({ consent: privacyRequired })
    await controller.start()
    sdk.showPrivacyOptionsForm.mockRejectedValueOnce(new Error('Form unavailable'))
    await controller.openPrivacyOptions()
    expect(states.at(-1)).toMatchObject({ adsStatus: adsMessages.privacyError, isPrivacyBusy: false, privacyOptionsRequired: true })
    expect(height).toHaveBeenLastCalledWith(0)
    expect(sdk.showBanner).toHaveBeenCalledOnce()
    await controller.openPrivacyOptions()
    expect(sdk.showPrivacyOptionsForm).toHaveBeenCalledTimes(2)
    expect(sdk.showBanner).toHaveBeenCalledTimes(2)
    await controller.dispose()
  })
})
