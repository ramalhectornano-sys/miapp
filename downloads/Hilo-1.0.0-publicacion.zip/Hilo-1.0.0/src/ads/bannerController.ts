import {
  AdmobConsentStatus,
  BannerAdPluginEvents,
} from '@capacitor-community/admob'
import type { AdMobPlugin, AdmobConsentInfo, BannerAdOptions, BannerDefinitions } from '@capacitor-community/admob'
import type { PluginListenerHandle } from '@capacitor/core'

export type BannerSdk = Pick<AdMobPlugin,
  'requestConsentInfo' | 'showConsentForm' | 'showPrivacyOptionsForm' | 'initialize' |
  'showBanner' | 'hideBanner' | 'resumeBanner' | 'removeBanner'> & Pick<BannerDefinitions, 'addListener'>

export type BannerState = {
  isNativeAndroid: boolean
  adsStatus: string
  privacyOptionsRequired: boolean
  isPrivacyBusy: boolean
}

export const adsMessages = {
  web: 'Los anuncios están disponibles en la app para Android.',
  consent: 'Consultando opciones de privacidad…',
  loading: 'Cargando anuncio…',
  test: 'Anuncio de prueba.',
  live: 'Publicidad.',
  denied: 'Anuncios desactivados por privacidad.',
  unavailable: 'Anuncios no disponibles por el momento.',
  privacyError: 'No se pudieron actualizar las opciones de privacidad.',
} as const

/** One native banner exists per process. Serialize teardown before the next mount. */
export function createSerialExecutor() {
  let tail: Promise<unknown> = Promise.resolve()
  return {
    run<T>(operation: () => Promise<T>): Promise<T> {
      const next = tail.then(operation, operation)
      tail = next.catch(() => undefined)
      return next
    },
  }
}

type ControllerOptions = {
  sdk: BannerSdk
  isNativeAndroid: boolean
  blocked: boolean
  bannerOptions: BannerAdOptions
  onState: (state: BannerState) => void
  setBannerHeight: (height: number) => void
  executor?: ReturnType<typeof createSerialExecutor>
}

export function initialBannerState(isNativeAndroid: boolean): BannerState {
  return {
    isNativeAndroid,
    adsStatus: isNativeAndroid ? adsMessages.consent : adsMessages.web,
    privacyOptionsRequired: false,
    isPrivacyBusy: isNativeAndroid,
  }
}

export function createBannerController(options: ControllerOptions) {
  const { sdk, isNativeAndroid, bannerOptions, onState, setBannerHeight } = options
  const executor = options.executor ?? createSerialExecutor()
  let state = initialBannerState(isNativeAndroid)
  let alive = true
  let started = false
  let blocked = options.blocked
  let canRequestAds = false
  let initialized = false
  let listenersReady = false
  let bannerCreated = false
  let nativeVisible = false
  let failed = false
  let measuredHeight = 0
  const listeners: PluginListenerHandle[] = []

  const update = (patch: Partial<BannerState>) => {
    if (!alive) return
    state = { ...state, ...patch }
    onState(state)
  }
  const wantsBanner = () => alive && canRequestAds && !blocked && !state.isPrivacyBusy && !failed
  const updateHeight = () => setBannerHeight(wantsBanner() && nativeVisible ? measuredHeight : 0)
  const applyConsent = (info: AdmobConsentInfo) => {
    canRequestAds = info.canRequestAds === true
    update({ privacyOptionsRequired: info.privacyOptionsRequirementStatus === 'REQUIRED' })
  }
  const removeBanner = async () => {
    if (!bannerCreated) return
    await sdk.removeBanner()
    bannerCreated = false
    nativeVisible = false
    measuredHeight = 0
    updateHeight()
  }
  const unavailable = async () => {
    failed = true
    update({ adsStatus: adsMessages.unavailable })
    updateHeight()
    // showBanner may create a native view even if its promise subsequently rejects.
    try { await removeBanner() } catch { /* Final cleanup will try again. */ }
  }
  const reconcile = async () => {
    if (!alive || !initialized || !listenersReady) return
    if (!wantsBanner()) {
      updateHeight()
      if (bannerCreated && nativeVisible) {
        nativeVisible = false
        try { await sdk.hideBanner() } catch { await unavailable() }
      }
      return
    }
    if (bannerCreated && nativeVisible) return
    nativeVisible = true
    try {
      if (bannerCreated) {
        await sdk.resumeBanner()
      } else {
        update({ adsStatus: adsMessages.loading })
        bannerCreated = true
        await sdk.showBanner(bannerOptions)
      }
    } catch {
      await unavailable()
      return
    }
    // Consent, a modal, or teardown may have changed while the native call ran.
    if (!alive) return
    if (!wantsBanner() && bannerCreated && nativeVisible) {
      nativeVisible = false
      updateHeight()
      try { await sdk.hideBanner() } catch { await unavailable() }
    } else {
      updateHeight()
    }
  }
  const enqueueReconcile = () => {
    void executor.run(reconcile)
  }
  const prepareAds = async () => {
    if (!alive || !canRequestAds) return
    if (!initialized) {
      await sdk.initialize({ initializeForTesting: bannerOptions.isTesting })
      initialized = true
    }
    if (!alive || listenersReady) return
    listeners.push(await sdk.addListener(BannerAdPluginEvents.SizeChanged, ({ height }) => {
      if (!alive || !bannerCreated) return
      measuredHeight = Number.isFinite(height) && height > 0 ? height : 0
      updateHeight()
      if (!wantsBanner()) enqueueReconcile()
    }))
    if (!alive) return
    listeners.push(await sdk.addListener(BannerAdPluginEvents.Loaded, () => {
      if (!alive || !bannerCreated || failed) return
      update({ adsStatus: bannerOptions.isTesting ? adsMessages.test : adsMessages.live })
      updateHeight()
      if (!wantsBanner()) enqueueReconcile()
    }))
    if (!alive) return
    listeners.push(await sdk.addListener(BannerAdPluginEvents.FailedToLoad, () => {
      if (!alive || !bannerCreated) return
      // Android destroys the failed AdView. Do not hide/resume or retry it.
      failed = true
      bannerCreated = false
      nativeVisible = false
      measuredHeight = 0
      update({ adsStatus: adsMessages.unavailable })
      updateHeight()
    }))
    listenersReady = true
  }

  return {
    start(): Promise<void> {
      if (started || !alive) return Promise.resolve()
      started = true
      setBannerHeight(0)
      if (!isNativeAndroid) return Promise.resolve()
      return executor.run(async () => {
        if (!alive) return
        try {
          let consent = await sdk.requestConsentInfo()
          if (!alive) return
          if (consent.status === AdmobConsentStatus.REQUIRED && consent.isConsentFormAvailable) {
            consent = await sdk.showConsentForm()
            if (!alive) return
          }
          applyConsent(consent)
          update({ isPrivacyBusy: false, adsStatus: canRequestAds ? adsMessages.loading : adsMessages.denied })
          if (!canRequestAds) return
          await prepareAds()
          await reconcile()
        } catch {
          update({ isPrivacyBusy: false })
          await unavailable()
        }
      })
    },
    setBlocked(nextBlocked: boolean): Promise<void> {
      blocked = nextBlocked
      updateHeight()
      if (!isNativeAndroid || !alive) return Promise.resolve()
      return executor.run(reconcile)
    },
    openPrivacyOptions(): Promise<void> {
      if (!isNativeAndroid || !alive || !state.privacyOptionsRequired || state.isPrivacyBusy) return Promise.resolve()
      update({ isPrivacyBusy: true })
      updateHeight()
      return executor.run(async () => {
        if (!alive) return
        try {
          // Destroy ads loaded with the previous preferences before opening UMP.
          await removeBanner()
          if (!alive) return
          await sdk.showPrivacyOptionsForm()
          if (!alive) return
          applyConsent(await sdk.requestConsentInfo())
          if (!alive) return
          failed = false
          update({ isPrivacyBusy: false, adsStatus: canRequestAds ? adsMessages.loading : adsMessages.denied })
          await prepareAds()
          await reconcile()
        } catch {
          canRequestAds = false
          update({ isPrivacyBusy: false, adsStatus: adsMessages.privacyError })
          updateHeight()
          await reconcile()
        }
      })
    },
    dispose(): Promise<void> {
      if (!alive) return Promise.resolve()
      alive = false
      setBannerHeight(0)
      if (!isNativeAndroid) return Promise.resolve()
      return executor.run(async () => {
        // Each subscription belongs to this mount; never clear another owner's listeners.
        await Promise.allSettled(listeners.map(listener => listener.remove()))
        try { await removeBanner() } catch { /* Do not block the next mount on SDK failure. */ }
      })
    },
  }
}
