import { BannerAdPosition, BannerAdSize } from '@capacitor-community/admob'
import type { BannerAdOptions } from '@capacitor-community/admob'

export const TEST_BANNER_ID = 'ca-app-pub-3940256099942544/6300978111'
export const LIVE_BANNER_ID = 'ca-app-pub-4739373930169128/7981007269'

export function supportsNativeAds(runtime: { isNativePlatform: () => boolean; getPlatform: () => string }): boolean {
  return runtime.isNativePlatform() && runtime.getPlatform() === 'android'
}

/** Release builds also use test ads unless the publisher explicitly opts in. */
export function getBannerOptions(liveAds: string | undefined): BannerAdOptions {
  const live = liveAds === 'true'
  return {
    adId: live ? LIVE_BANNER_ID : TEST_BANNER_ID,
    isTesting: !live,
    adSize: BannerAdSize.ADAPTIVE_BANNER,
    position: BannerAdPosition.BOTTOM_CENTER,
    margin: 0,
  }
}
