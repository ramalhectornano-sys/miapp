import { sessionExerciseIds } from '../data/exercises';
import { training } from '../data/training';

/** Progress stays on this device. No account or network is needed. */
export const STORAGE_KEY = 'hilo-progress-v1';

export interface ClarityAssessment {
  exerciseId: string;
  before: number;
  after: number;
}

export interface PracticeRecord {
  id: string;
  completedAt: string;
  exerciseIds: string[];
  durationSeconds: number;
  xp: number;
  mode: 'session' | 'exercise';
  assessments?: ClarityAssessment[];
}

export interface Progress {
  version: 1;
  records: PracticeRecord[];
  savedQuoteIds: string[];
  reminderEnabled: boolean;
}

export interface ProgressStorage {
  getItem(key: string): string | null;
  setItem(key: string, value: string): void;
}

export interface ProgressLevel {
  number: number;
  name: string;
  minXp: number;
  nextXp: number;
}

export interface ProgressStats {
  totalXp: number;
  level: ProgressLevel;
  /** Percentage toward the next level, from 0 to 100. */
  levelProgress: number;
  completedSessions: number;
  completedExercises: number;
  streak: number;
  todayCompleted: boolean;
  week: { key: string; label: string; completed: boolean; isToday: boolean }[];
}

type PracticeInput = Omit<PracticeRecord, 'id' | 'completedAt'>;

export function emptyProgress(): Progress {
  return { version: 1, records: [], savedQuoteIds: [], reminderEnabled: false };
}

function getStorage(storage?: ProgressStorage): ProgressStorage | undefined {
  if (storage) return storage;
  try {
    return typeof window === 'undefined' ? undefined : window.localStorage;
  } catch {
    // Some browsers disable local storage, even when the API exists.
    return undefined;
  }
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function uniqueIds(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  return [...new Set(value.filter((id): id is string => typeof id === 'string' && id.trim().length > 0))];
}

function isNonnegativeInteger(value: unknown): value is number {
  return typeof value === 'number' && Number.isSafeInteger(value) && value >= 0;
}

function validAssessments(value: unknown, exerciseIds: string[]): ClarityAssessment[] {
  if (!Array.isArray(value)) return [];
  const seen = new Set<string>();
  return value.flatMap(item => {
    if (!isObject(item) || typeof item.exerciseId !== 'string' || seen.has(item.exerciseId)
      || !exerciseIds.includes(item.exerciseId) || !training.some(exercise => exercise.id === item.exerciseId)
      || !isNonnegativeInteger(item.before) || item.before < 1 || item.before > 5
      || !isNonnegativeInteger(item.after) || item.after < 1 || item.after > 5) return [];
    seen.add(item.exerciseId);
    return [{ exerciseId: item.exerciseId, before: item.before, after: item.after }];
  });
}

function parseRecord(value: unknown): PracticeRecord | undefined {
  if (!isObject(value)
    || typeof value.id !== 'string' || value.id.trim().length === 0
    || typeof value.completedAt !== 'string'
    || !/^\d{4}-\d{2}-\d{2}T/.test(value.completedAt)
    || !Number.isFinite(Date.parse(value.completedAt))
    || !Array.isArray(value.exerciseIds)
    || !isNonnegativeInteger(value.durationSeconds)
    || !isNonnegativeInteger(value.xp)
    || (value.mode !== 'session' && value.mode !== 'exercise')) return undefined;

  const exerciseIds = uniqueIds(value.exerciseIds);
  if (exerciseIds.length === 0) return undefined;
  return {
    id: value.id,
    completedAt: value.completedAt,
    exerciseIds,
    durationSeconds: value.durationSeconds,
    xp: value.xp,
    mode: value.mode,
    ...(validAssessments(value.assessments, exerciseIds).length ? { assessments: validAssessments(value.assessments, exerciseIds) } : {}),
  };
}

export function loadProgress(storage?: ProgressStorage): Progress {
  try {
    const stored = getStorage(storage)?.getItem(STORAGE_KEY);
    if (!stored) return emptyProgress();
    const data: unknown = JSON.parse(stored);
    if (!isObject(data) || data.version !== 1) return emptyProgress();

    const records: PracticeRecord[] = [];
    const seen = new Set<string>();
    if (Array.isArray(data.records)) {
      for (const value of data.records) {
        const record = parseRecord(value);
        if (record && !seen.has(record.id)) {
          records.push(record);
          seen.add(record.id);
        }
      }
    }
    return {
      version: 1,
      records,
      savedQuoteIds: uniqueIds(data.savedQuoteIds),
      reminderEnabled: data.reminderEnabled === true,
    };
  } catch {
    return emptyProgress();
  }
}

/** False means practice can continue, but this browser could not save it. */
export function saveProgress(progress: Progress, storage?: ProgressStorage): boolean {
  try {
    const target = getStorage(storage);
    if (!target) return false;
    target.setItem(STORAGE_KEY, JSON.stringify(progress));
    return true;
  } catch {
    return false;
  }
}

export function addPractice(progress: Progress, input: PracticeInput, now = new Date()): Progress {
  const exerciseIds = uniqueIds(input.exerciseIds);
  if (!Number.isFinite(now.getTime()) || exerciseIds.length === 0
    || !isNonnegativeInteger(input.durationSeconds) || !isNonnegativeInteger(input.xp)
    || (input.mode !== 'session' && input.mode !== 'exercise')) return progress;

  const id = typeof globalThis.crypto?.randomUUID === 'function'
    ? globalThis.crypto.randomUUID()
    : `${now.getTime()}-${Math.random().toString(36).slice(2)}-${progress.records.length}`;
  return {
    ...progress,
    records: [...progress.records, {
      id,
      completedAt: now.toISOString(),
      exerciseIds,
      durationSeconds: input.durationSeconds,
      xp: input.xp,
      mode: input.mode,
      ...(validAssessments(input.assessments, exerciseIds).length ? { assessments: validAssessments(input.assessments, exerciseIds) } : {}),
    }],
  };
}

/** Counts real practice records; ratings are subjective and never inferred from XP. */
export function getTrainingProgress(progress: Progress) {
  const completedIds = new Set(progress.records.flatMap(record => record.exerciseIds));
  const items = training.map(exercise => ({
    ...exercise,
    count: progress.records.filter(record => record.exerciseIds.includes(exercise.id)).length,
    completed: completedIds.has(exercise.id),
  }));
  const ordered = progress.records.slice().sort((a, b) => Date.parse(a.completedAt) - Date.parse(b.completedAt));
  const clarity = ordered.flatMap(record => (record.assessments ?? [])
    .filter(item => item.exerciseId === 'oracion').map(item => ({ ...item, date: record.completedAt })));
  return {
    items, completedCount: items.filter(item => item.completed).length,
    nextId: items.find(item => !item.completed)?.id ?? training[0].id,
    clarity,
  };
}

export function toggleSavedQuote(progress: Progress, id: string): Progress {
  if (!id.trim()) return progress;
  return {
    ...progress,
    savedQuoteIds: progress.savedQuoteIds.includes(id)
      ? progress.savedQuoteIds.filter((savedId) => savedId !== id)
      : [...progress.savedQuoteIds, id],
  };
}

function dayKey(date: Date): string {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}

function levelForXp(totalXp: number): ProgressLevel {
  const levels: ProgressLevel[] = [
    { number: 1, name: 'Semilla', minXp: 0, nextXp: 100 },
    { number: 2, name: 'Brote', minXp: 100, nextXp: 250 },
    { number: 3, name: 'Rama', minXp: 250, nextXp: 500 },
    { number: 4, name: 'Horizonte', minXp: 500, nextXp: 1000 },
  ];
  for (const level of levels) {
    if (totalXp < level.nextXp) return level;
  }
  const step = Math.floor((totalXp - 1000) / 1000);
  return { number: 5 + step, name: 'Voz propia', minXp: 1000 + step * 1000, nextXp: 2000 + step * 1000 };
}

export function getProgressStats(progress: Progress, now = new Date()): ProgressStats {
  const totalXp = progress.records.reduce((total, record) => total + record.xp, 0);
  const level = levelForXp(totalXp);
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const todayKey = dayKey(today);
  const practicedDays = new Set(progress.records.map((record) => dayKey(new Date(record.completedAt))));
  const todayCompleted = practicedDays.has(todayKey);

  const cursor = new Date(today);
  if (!todayCompleted) cursor.setDate(cursor.getDate() - 1);
  let streak = 0;
  while (practicedDays.has(dayKey(cursor))) {
    streak++;
    cursor.setDate(cursor.getDate() - 1);
  }

  const monday = new Date(today);
  monday.setDate(monday.getDate() - (monday.getDay() + 6) % 7);
  const labels = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];
  const week = labels.map((label, index) => {
    const day = new Date(monday);
    day.setDate(day.getDate() + index);
    const key = dayKey(day);
    return { key, label, completed: practicedDays.has(key), isToday: key === todayKey };
  });

  return {
    totalXp,
    level,
    levelProgress: Math.min(100, Math.max(0, (totalXp - level.minXp) / (level.nextXp - level.minXp) * 100)),
    completedSessions: progress.records.filter((record) =>
      record.mode === 'session' && sessionExerciseIds.every((id) => record.exerciseIds.includes(id)),
    ).length,
    completedExercises: progress.records.reduce((total, record) => total + record.exerciseIds.length, 0),
    streak,
    todayCompleted,
    week,
  };
}
