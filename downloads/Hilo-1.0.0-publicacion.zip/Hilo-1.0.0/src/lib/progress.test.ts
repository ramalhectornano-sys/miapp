import { afterEach, describe, expect, it, vi } from 'vitest';
import {
  STORAGE_KEY,
  addPractice,
  emptyProgress,
  getProgressStats,
  getTrainingProgress,
  loadProgress,
  saveProgress,
  toggleSavedQuote,
  type PracticeRecord,
  type Progress,
  type ProgressStorage,
} from './progress';

function memoryStorage(initial?: string): ProgressStorage {
  const values = new Map<string, string>();
  if (initial !== undefined) values.set(STORAGE_KEY, initial);
  return {
    getItem: (key) => values.get(key) ?? null,
    setItem: (key, value) => { values.set(key, value); },
  };
}

function record(completedAt: string, overrides: Partial<PracticeRecord> = {}): PracticeRecord {
  return {
    id: completedAt,
    completedAt,
    exerciseIds: ['ordena', 'recuerda', 'pausa'],
    durationSeconds: 300,
    xp: 60,
    mode: 'session',
    ...overrides,
  };
}

function progressWith(...records: PracticeRecord[]): Progress {
  return { ...emptyProgress(), records };
}

afterEach(() => {
  vi.unstubAllGlobals();
  vi.unstubAllEnvs();
});

describe('local progress storage', () => {
  it('starts with no invented practice or achievements', () => {
    const progress = loadProgress(memoryStorage());
    expect(progress).toEqual(emptyProgress());
    expect(getProgressStats(progress, new Date(2026, 9, 9))).toMatchObject({
      totalXp: 0,
      completedSessions: 0,
      completedExercises: 0,
      streak: 0,
      todayCompleted: false,
      level: { number: 1, name: 'Semilla' },
      levelProgress: 0,
    });
  });

  it('restores completed exercises, saved reflections, and the reminder preference', () => {
    const storage = memoryStorage();
    let progress = addPractice(emptyProgress(), {
      exerciseIds: ['ordena', 'recuerda', 'pausa'],
      durationSeconds: 293,
      xp: 60,
      mode: 'session',
    }, new Date('2026-10-09T12:00:00Z'));
    progress = { ...toggleSavedQuote(progress, 'reflection-1'), reminderEnabled: true };

    expect(saveProgress(progress, storage)).toBe(true);
    expect(loadProgress(storage)).toEqual(progress);
    expect(progress.records[0].id.length).toBeGreaterThan(0);
    expect(progress.records[0].completedAt).toBe('2026-10-09T12:00:00.000Z');
  });

  it.each(['{broken json', 'null', '[]', '{"version":2,"records":[]}', 'true'])
    ('recovers safely from malformed or unsupported data: %s', (stored) => {
      expect(loadProgress(memoryStorage(stored))).toEqual(emptyProgress());
    });

  it('salvages valid records and removes malformed entries and duplicates', () => {
    const valid = record('2026-10-09T12:00:00Z');
    const stored = JSON.stringify({
      version: 1,
      records: [
        valid,
        valid,
        { ...valid, id: 'negative', xp: -5 },
        { ...valid, id: 'invalid-time', completedAt: 'yesterday' },
        { ...valid, id: 'empty', exerciseIds: [] },
        { ...valid, id: 'wrong-mode', mode: 'finished' },
        null,
      ],
      savedQuoteIds: ['reflection-1', null, '', 'reflection-1', 7],
      reminderEnabled: 'yes',
    });
    expect(loadProgress(memoryStorage(stored))).toEqual({
      version: 1,
      records: [valid],
      savedQuoteIds: ['reflection-1'],
      reminderEnabled: false,
    });
  });

  it('keeps practice usable when storage is absent or denied', () => {
    vi.stubGlobal('window', undefined);
    expect(loadProgress()).toEqual(emptyProgress());
    expect(saveProgress(emptyProgress())).toBe(false);

    const blocked = {
      getItem: () => { throw new Error('Storage access denied'); },
      setItem: () => { throw new Error('Quota exceeded'); },
    };
    expect(loadProgress(blocked)).toEqual(emptyProgress());
    expect(saveProgress(emptyProgress(), blocked)).toBe(false);

    const browser = Object.defineProperty({}, 'localStorage', {
      get: () => { throw new Error('Storage access denied'); },
    });
    vi.stubGlobal('window', browser);
    expect(loadProgress()).toEqual(emptyProgress());
    expect(saveProgress(emptyProgress())).toBe(false);
  });
});

describe('practice and saved reflections', () => {
  it('adds completed practice without mutating prior progress and counts exercise completions', () => {
    const original = emptyProgress();
    const session = addPractice(original, {
      exerciseIds: ['ordena', 'recuerda', 'pausa', 'ordena'], durationSeconds: 300, xp: 60, mode: 'session',
    }, new Date('2026-10-09T12:00:00Z'));
    const individual = addPractice(session, {
      exerciseIds: ['historia'], durationSeconds: 50, xp: 20, mode: 'exercise',
    }, new Date('2026-10-09T12:05:00Z'));

    expect(original.records).toEqual([]);
    expect(session.records).toHaveLength(1);
    expect(individual.records[0].exerciseIds).toEqual(['ordena', 'recuerda', 'pausa']);
    expect(individual.records[0].id).not.toBe(individual.records[1].id);
    expect(getProgressStats(individual)).toMatchObject({ totalXp: 80, completedSessions: 1, completedExercises: 4 });
  });

  it('ignores invalid completions and toggles saved reflections without mutating', () => {
    const original = emptyProgress();
    expect(addPractice(original, {
      exerciseIds: [], durationSeconds: 0, xp: 20, mode: 'exercise',
    })).toBe(original);
    expect(addPractice(original, {
      exerciseIds: ['one'], durationSeconds: 60, xp: -1, mode: 'exercise',
    })).toBe(original);
    expect(addPractice(original, {
      exerciseIds: ['one'], durationSeconds: 60, xp: 20, mode: 'exercise',
    }, new Date('invalid'))).toBe(original);

    const saved = toggleSavedQuote(original, 'reflection-1');
    expect(original.savedQuoteIds).toEqual([]);
    expect(saved.savedQuoteIds).toEqual(['reflection-1']);
    expect(toggleSavedQuote(saved, 'reflection-1').savedQuoteIds).toEqual([]);
    expect(toggleSavedQuote(original, ' ')).toBe(original);
  });
});

describe('calendar progress and levels', () => {
  it('counts a session only when all three required exercises were completed', () => {
    const practice = progressWith(
      record('2026-10-09T12:00:00Z'),
      record('2026-10-09T12:10:00Z', { exerciseIds: ['ordena'] }),
      record('2026-10-09T12:20:00Z', { exerciseIds: ['ordena', 'recuerda', 'recuerda'] }),
      record('2026-10-09T12:30:00Z', { exerciseIds: ['ordena', 'historia', 'lectura'] }),
      record('2026-10-09T12:40:00Z', { mode: 'exercise' }),
    );
    expect(getProgressStats(practice, new Date('2026-10-09T13:00:00Z')).completedSessions).toBe(1);
  });

  it('preserves a day’s practice and streak when an exercise was completed but the session was partial', () => {
    const practice = progressWith(record(new Date(2026, 9, 9, 12).toISOString(), {
      exerciseIds: ['ordena'], xp: 30, durationSeconds: 120,
    }));
    expect(getProgressStats(practice, new Date(2026, 9, 9, 13))).toMatchObject({
      completedSessions: 0, completedExercises: 1, todayCompleted: true, streak: 1, totalXp: 30,
    });
  });

  it('uses local calendar days around midnight instead of UTC date slices', () => {
    vi.stubEnv('TZ', 'America/Araguaina');
    const practice = progressWith(record('2026-10-09T01:30:00Z'));
    const stats = getProgressStats(practice, new Date('2026-10-09T02:00:00Z'));

    expect(stats.todayCompleted).toBe(true);
    expect(stats.week.find((day) => day.isToday)?.key).toBe('2026-10-08');
    expect(stats.week.find((day) => day.key === '2026-10-08')?.completed).toBe(true);
    expect(stats.week.find((day) => day.key === '2026-10-09')?.completed).toBe(false);
  });

  it('counts consecutive calendar days once and keeps a streak alive before today’s practice', () => {
    const practice = progressWith(
      record(new Date(2026, 9, 6, 12).toISOString()),
      record(new Date(2026, 9, 7, 12).toISOString()),
      record(new Date(2026, 9, 8, 12).toISOString()),
      record(new Date(2026, 9, 8, 15).toISOString()),
    );
    expect(getProgressStats(practice, new Date(2026, 9, 9, 10))).toMatchObject({ streak: 3, todayCompleted: false });
    expect(getProgressStats(practice, new Date(2026, 9, 10, 10))).toMatchObject({ streak: 0, todayCompleted: false });

    const today = addPractice(practice, {
      exerciseIds: ['one'], durationSeconds: 60, xp: 20, mode: 'exercise',
    }, new Date(2026, 9, 9, 12));
    expect(getProgressStats(today, new Date(2026, 9, 9, 14))).toMatchObject({ streak: 4, todayCompleted: true });
  });

  it('keeps consecutive days across a month boundary', () => {
    const practice = progressWith(
      record(new Date(2026, 8, 30, 12).toISOString()),
      record(new Date(2026, 9, 1, 12).toISOString()),
    );
    expect(getProgressStats(practice, new Date(2026, 9, 2)).streak).toBe(2);
  });

  it('shows Monday through Sunday, including Sunday and weeks crossing a year', () => {
    const stats = getProgressStats(emptyProgress(), new Date(2027, 0, 3, 12));
    expect(stats.week.map((day) => day.key)).toEqual([
      '2026-12-28', '2026-12-29', '2026-12-30', '2026-12-31', '2027-01-01', '2027-01-02', '2027-01-03',
    ]);
    expect(stats.week.map((day) => day.label)).toEqual(['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom']);
    expect(stats.week.filter((day) => day.isToday)).toEqual([
      { key: '2027-01-03', label: 'Dom', completed: false, isToday: true },
    ]);
  });

  it.each([
    [0, 1, 'Semilla', 0, 100, 0],
    [50, 1, 'Semilla', 0, 100, 50],
    [100, 2, 'Brote', 100, 250, 0],
    [175, 2, 'Brote', 100, 250, 50],
    [250, 3, 'Rama', 250, 500, 0],
    [500, 4, 'Horizonte', 500, 1000, 0],
    [1000, 5, 'Voz propia', 1000, 2000, 0],
    [2000, 6, 'Voz propia', 2000, 3000, 0],
    [2500, 6, 'Voz propia', 2000, 3000, 50],
  ])('sets the correct level at %i XP', (xp, number, name, minXp, nextXp, percent) => {
    const stats = getProgressStats(progressWith(record('2026-10-09T12:00:00Z', { xp: xp as number })));
    expect(stats.level).toEqual({ number, name, minXp, nextXp });
    expect(stats.levelProgress).toBe(percent);
  });
});


describe('guided practice and clarity ratings', () => {
  it('preserves old progress without inventing ratings or training completion', () => {
    const previous = progressWith(record('2026-10-09T12:00:00.000Z'));
    const loaded = loadProgress(memoryStorage(JSON.stringify(previous)));
    expect(loaded).toEqual(previous);
    expect(getTrainingProgress(loaded)).toMatchObject({ completedCount: 0, clarity: [], nextId: 'oracion' });
  });

  it('keeps only complete, in-range ratings for completed guided exercises, without arbitrary data', () => {
    const stored = progressWith(record('2026-10-09T12:00:00.000Z', {
      exerciseIds: ['oracion', 'dinero'],
      assessments: [
        { exerciseId: 'oracion', before: 2, after: 4, answer: 'private answer' },
        { exerciseId: 'oracion', before: 1, after: 5 },
        { exerciseId: 'dinero', before: 0, after: 5 },
        { exerciseId: 'decision', before: 2, after: 3 },
        { exerciseId: 'dinero', before: 2.5, after: 4 },
        { exerciseId: 'dinero', before: 2, after: 6 },
      ] as unknown as PracticeRecord['assessments'],
    }));
    const loaded = loadProgress(memoryStorage(JSON.stringify(stored)));
    expect(loaded.records[0].assessments).toEqual([{ exerciseId: 'oracion', before: 2, after: 4 }]);
    expect(JSON.stringify(loaded)).not.toContain('private answer');
  });

  it('counts repeated practice without inflating distinct tools and sorts comparison chronologically', () => {
    const progress = progressWith(
      record('2026-10-10T12:00:00.000Z', { exerciseIds: ['oracion'], assessments: [{ exerciseId: 'oracion', before: 3, after: 2 }] }),
      record('2026-10-09T12:00:00.000Z', { exerciseIds: ['oracion', 'critico'], assessments: [{ exerciseId: 'oracion', before: 1, after: 4 }] }),
    );
    const route = getTrainingProgress(progress);
    expect(route.completedCount).toBe(2);
    expect(route.items.find(item => item.id === 'oracion')?.count).toBe(2);
    expect(route.nextId).toBe('explica');
    expect(route.clarity.map(item => item.after)).toEqual([4, 2]);
  });

  it('writes and reloads ratings without making them mandatory for progress', () => {
    let progress = addPractice(emptyProgress(), { mode: 'exercise', exerciseIds: ['oracion'], durationSeconds: 90, xp: 35,
      assessments: [{ exerciseId: 'oracion', before: 3, after: 2 }] });
    progress = addPractice(progress, { mode: 'exercise', exerciseIds: ['dinero'], durationSeconds: 80, xp: 35 });
    const storage = memoryStorage();
    expect(saveProgress(progress, storage)).toBe(true);
    const loaded = loadProgress(storage);
    expect(loaded.records[0].assessments).toEqual([{ exerciseId: 'oracion', before: 3, after: 2 }]);
    expect(loaded.records[1].assessments).toBeUndefined();
    expect(getProgressStats(loaded).totalXp).toBe(70);
  });
});
