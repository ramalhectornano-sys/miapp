import { useCallback, useEffect, useRef, useState } from 'react'
import { ArrowRight, ArrowUpRight, AudioLines, BookOpen, Check, CheckCircle2, ChevronRight, Clock3, Download, Flame, Heart, House, Layers3, Leaf, Lightbulb, Link2, Menu, MessageCircle, Settings2, Sparkles, Sprout, TrendingUp, Trophy, X } from 'lucide-react'
import PracticeModal from './components/PracticeModal'
import TrainingRoute, { SkillsProgress } from './components/TrainingRoute'
import PracticeMethods from './components/PracticeMethods'
import PrivacyInformation from './components/PrivacyInformation'
import useAdMobBanner from './ads/useAdMobBanner'
import { adsMessages } from './ads/bannerController'
import { exercises, sessionExerciseIds } from './data/exercises'
import type { Exercise } from './data/exercises'
import { addPractice, emptyProgress, getProgressStats, loadProgress, saveProgress, toggleSavedQuote } from './lib/progress'
import type { ClarityAssessment, Progress } from './lib/progress'

type Page = 'today' | 'exercises' | 'progress' | 'library'
type Category = 'Todos' | Exercise['category']
type ActivePractice = { exerciseIds: string[]; mode: 'session' | 'exercise'; quote?: { text: string; author: string; book: string } }
const navigation = [
  { id: 'today' as Page, label: 'Hoy', icon: House },
  { id: 'exercises' as Page, label: 'Ejercicios', icon: Layers3 },
  { id: 'progress' as Page, label: 'Mi progreso', icon: TrendingUp },
  { id: 'library' as Page, label: 'Biblioteca', icon: BookOpen },
]
const quotes = [
  { id: 'camino', text: 'Caminante, no hay camino, se hace camino al andar.', author: 'Antonio Machado', book: 'Campos de Castilla', prompt: 'Pensá en un pequeño paso que podés dar hoy.' },
  { id: 'todavia', text: 'Hoy es siempre todavía.', author: 'Antonio Machado', book: 'Nuevas canciones', prompt: '¿Qué te gustaría empezar o retomar?' },
  { id: 'leer', text: 'El que lee mucho y anda mucho, ve mucho y sabe mucho.', author: 'Miguel de Cervantes', book: 'Don Quijote de la Mancha', prompt: 'Recordá algo que aprendiste de una experiencia.' },
  { id: 'libertad', text: 'La libertad, Sancho, es uno de los más preciosos dones que a los hombres dieron los cielos.', author: 'Miguel de Cervantes', book: 'Don Quijote de la Mancha', prompt: 'Explicá con tus palabras qué significa para ti la libertad.' },
]
const exerciseIcons: Record<string, typeof Layers3> = { layers: Layers3, spark: Sparkles, leaf: Leaf, chat: MessageCircle, link: Link2, book: BookOpen }

function ThreadIllustration() {
  return <svg className="thread-illustration" viewBox="0 0 390 290" fill="none" aria-hidden="true">
    <defs><pattern id="dots" x="0" y="0" width="16" height="16" patternUnits="userSpaceOnUse"><circle cx="2" cy="2" r="1" fill="#cda68f" opacity=".22" /></pattern></defs>
    <rect x="36" y="13" width="326" height="263" rx="80" fill="url(#dots)" />
    <path d="M229 218V106a62 62 0 0 1 124 0v112" fill="#c0cabc" />
    <path d="M271 218V106a20 20 0 0 1 40 0v112" fill="#f7e7d8" />
    <circle cx="105" cy="82" r="43" fill="#e99c7d" />
    <path d="M6 205c26-27 25-80 58-74 35 7-22 75 10 86 45 15 46-111 10-92-34 18 47 123 64 73 19-56-26-76-35-36-11 50 60 57 49 7-8-37-54-18-20 11s49 22 55-1c10-40-35-34-30-8 4 19 39 19 48 7 13-17 16-43 33-43h89" stroke="#365b4d" strokeWidth="3.6" strokeLinecap="round" />
    <rect x="145" y="20" width="129" height="70" rx="8" fill="#fffcf6" transform="rotate(-8 145 20)" />
    <path d="m164 34 85-12M166 45l63-9M168 56l76-11" stroke="#c5c1b5" strokeWidth="2.8" strokeLinecap="round" />
    <path d="m306 239 7-23 9 17 20 3-15 10 2 21-14-16-20 4Z" fill="#e99c7d" />
    <path d="M87 244h158" stroke="#d7b9a4" strokeWidth="1.5" />
    <text x="119" y="267" fill="#8b7968" fontSize="11" letterSpacing="2">ENCONTRÁ TU HILO</text>
    <path d="m25 71 8 3m-2-15-2 8m-11-3 7 2" stroke="#a8b5a3" strokeWidth="2" strokeLinecap="round" />
  </svg>
}

function ExerciseCard({ exercise, onStart }: { exercise: Exercise; onStart: (id: string) => void }) {
  const Icon = exerciseIcons[exercise.icon] || Lightbulb
  return <button className="exercise-card" onClick={() => onStart(exercise.id)}>
    <div className="exercise-card-top"><span className={`icon-tile ${exercise.color}`}><Icon size={23} strokeWidth={1.7} /></span><ArrowUpRight className="card-arrow" size={19} /></div>
    <span className={`category-label category-${exercise.color}`}>{exercise.category}</span>
    <h3>{exercise.title}</h3><p>{exercise.description}</p>
    <div className="exercise-card-meta"><span><Clock3 size={13} /> {exercise.duration / 60 % 1 === 0 ? `${exercise.duration / 60} min` : `${exercise.duration / 60} min`.replace('.', ',')}</span><span>+{exercise.xp} puntos</span></div>
  </button>
}

function Week({ progress }: { progress: Progress }) {
  const stats = getProgressStats(progress)
  return <div className="week-days">{stats.week.map(day => <div key={day.key} className={`week-day ${day.isToday ? 'is-today' : ''}`}><span>{day.label}</span><span className={`day-dot ${day.completed ? 'is-done' : ''}`}>{day.completed ? <Check size={16} /> : day.isToday ? <span className="today-dot" /> : <span className="empty-dot" />}</span></div>)}</div>
}

function SettingsDialog({ progress, onChange, onClose, nativeAds, privacyOptionsRequired, privacyBusy, privacyMessage, onPrivacyOptions }: { progress: Progress; onChange: (p: Progress) => void; onClose: () => void; nativeAds: boolean; privacyOptionsRequired: boolean; privacyBusy: boolean; privacyMessage: string; onPrivacyOptions: () => Promise<void> }) {
  const [confirmReset, setConfirmReset] = useState(false)
  const [exported, setExported] = useState(false)
  const dialogRef = useRef<HTMLDivElement>(null)
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null
    dialogRef.current?.querySelector<HTMLButtonElement>('button')?.focus()
    const keydown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose()
      if (event.key === 'Tab') {
        const controls = Array.from(dialogRef.current?.querySelectorAll<HTMLElement>('button, input, a, summary') || []).filter(el => !el.hasAttribute('disabled') && el.getClientRects().length > 0)
        const first = controls[0], last = controls[controls.length - 1]
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus() }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus() }
      }
    }
    document.addEventListener('keydown', keydown)
    const overflow = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => { document.removeEventListener('keydown', keydown); document.body.style.overflow = overflow; previous?.focus() }
  }, [onClose])
  const exportData = () => {
    const blob = new Blob([JSON.stringify(progress, null, 2)], { type: 'application/json' })
    const href = URL.createObjectURL(blob)
    const anchor = document.createElement('a'); anchor.href = href; anchor.download = 'mi-progreso-hilo.json'; anchor.click(); URL.revokeObjectURL(href); setExported(true)
  }
  return <div className="dialog-overlay" onClick={event => { if (event.target === event.currentTarget) onClose() }}>
    <div className="settings-dialog" role="dialog" aria-modal="true" aria-labelledby="settings-title" ref={dialogRef}>
      <div className="dialog-header"><div><span className="eyebrow">TU ESPACIO</span><h2 id="settings-title">A tu manera</h2></div><button className="icon-button" aria-label="Cerrar ajustes" onClick={onClose}><X size={21} /></button></div>
      <p>Sin cuentas, sin suscripciones. Un lugar para practicar con tranquilidad.</p>
      <label className="preference-row"><span><strong>Una invitación cada día</strong><small>Muestra un recordatorio al abrir Hilo. No enviamos notificaciones.</small></span><input type="checkbox" checked={progress.reminderEnabled} onChange={e => onChange({ ...progress, reminderEnabled: e.target.checked })} /></label>
      <div className="privacy-note"><Leaf size={22} /><div><strong>Tu progreso se queda contigo</strong><p>Se guarda solo en este navegador. Tus respuestas no se guardan ni se envían. Borrar los datos del navegador elimina tu progreso.</p></div></div>
      <PrivacyInformation />
      {nativeAds && <section className="ads-settings" aria-labelledby="ads-settings-title"><strong id="ads-settings-title">Publicidad que sostiene Hilo</strong><p>Un banner de Google ayuda a mantener la app gratis. Se oculta mientras practicás. Tus respuestas no se comparten con los anunciantes; el SDK de Google puede procesar información del dispositivo para mostrar y medir anuncios.</p>{privacyOptionsRequired && <button className="button button-outline full-width" onClick={() => { void onPrivacyOptions() }} disabled={privacyBusy}>{privacyBusy ? 'Abriendo preferencias…' : 'Preferencias de privacidad de anuncios'}</button>}{privacyMessage === adsMessages.privacyError && <p role="status">{privacyMessage} Podés volver a intentarlo.</p>}</section>}
      <button className="button button-outline full-width" onClick={exportData}><Download size={17} />{exported ? 'Volver a descargar mi progreso' : 'Descargar mi progreso'}</button>
      {exported && <p className="feedback" role="status">Tu archivo está listo para guardar.</p>}
      {confirmReset ? <div className="reset-confirm"><p>¿Borrar todo el progreso y las frases guardadas? Esta acción no se puede deshacer.</p><div className="button-row"><button className="button button-outline" onClick={() => setConfirmReset(false)}>Conservar mi progreso</button><button className="button button-primary" onClick={() => { onChange(emptyProgress()); setConfirmReset(false) }}>Sí, borrar</button></div></div> : <button className="text-button reset-link" onClick={() => setConfirmReset(true)}>Reiniciar mi progreso</button>}
      <p className="settings-footnote">Hilo ofrece práctica de expresión y memoria. Los puntos reconocen tu constancia; no son una evaluación clínica.</p>
    </div>
  </div>
}

export default function App() {
  const [page, setPage] = useState<Page>('today')
  const [category, setCategory] = useState<Category>('Todos')
  const [progress, setProgress] = useState<Progress>(() => loadProgress())
  const [activePractice, setActivePractice] = useState<ActivePractice | null>(null)
  const [settingsOpen, setSettingsOpen] = useState(false)
  const [mobileNav, setMobileNav] = useState(false)
  const [isMobile, setIsMobile] = useState(() => window.matchMedia('(max-width: 760px)').matches)
  const navigationRef = useRef<HTMLElement>(null)
  const menuButtonRef = useRef<HTMLButtonElement>(null)
  const closeSettings = useCallback(() => setSettingsOpen(false), [])
  const ads = useAdMobBanner(Boolean(activePractice) || settingsOpen || mobileNav)
  const [onlySaved, setOnlySaved] = useState(false)
  const [storageIssue, setStorageIssue] = useState(false)
  const [notice, setNotice] = useState('')
  const titleRef = useRef<HTMLHeadingElement>(null)
  const stats = getProgressStats(progress)
  const formattedDate = new Intl.DateTimeFormat('es', { weekday: 'long', day: 'numeric', month: 'long' }).format(new Date())
  const changeProgress = (next: Progress) => { setProgress(next); setStorageIssue(!saveProgress(next)) }
  const navigate = (next: Page) => { setPage(next); setMobileNav(false); window.scrollTo({ top: 0, behavior: 'instant' }); requestAnimationFrame(() => titleRef.current?.focus()) }
  const startExercise = (id: string) => setActivePractice({ exerciseIds: [id], mode: 'exercise' })
  const startSession = () => setActivePractice({ exerciseIds: sessionExerciseIds, mode: 'session' })
  const onPracticeComplete = (result: { exerciseIds: string[]; durationSeconds: number; xp: number; assessments?: ClarityAssessment[] }) => {
    if (!activePractice) return
    if (result.exerciseIds.length === 0) {
      setNotice('Podés volver a practicar cuando quieras. No se guardó ninguna actividad.')
      setActivePractice(null)
      return
    }
    changeProgress(addPractice(progress, { ...result, mode: activePractice.mode }))
    setNotice(result.xp > 0 ? `Práctica guardada. Sumaste ${result.xp} puntos. ¡Un paso más!` : 'Tu pausa quedó registrada. Podés volver a practicar cuando quieras.')
    setActivePractice(null)
  }
  useEffect(() => {
    const media = window.matchMedia('(max-width: 760px)')
    const update = (event: MediaQueryListEvent) => { setIsMobile(event.matches); if (!event.matches) setMobileNav(false) }
    media.addEventListener('change', update)
    return () => media.removeEventListener('change', update)
  }, [])
  useEffect(() => {
    if (!mobileNav || !isMobile) return
    navigationRef.current?.querySelector<HTMLButtonElement>('[aria-current="page"]')?.focus()
    const previousOverflow = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    const handleKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') { event.preventDefault(); setMobileNav(false) }
      if (event.key === 'Tab') {
        const controls = Array.from(navigationRef.current?.querySelectorAll<HTMLElement>('a[href], button') || []).filter(el => el.getClientRects().length > 0)
        const first = controls[0], last = controls[controls.length - 1]
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus() }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus() }
      }
    }
    document.addEventListener('keydown', handleKey)
    return () => { document.removeEventListener('keydown', handleKey); document.body.style.overflow = previousOverflow; menuButtonRef.current?.focus() }
  }, [mobileNav, isMobile])
  useEffect(() => {
    if (!notice) return
    const timer = window.setTimeout(() => setNotice(''), 6000)
    return () => window.clearTimeout(timer)
  }, [notice])

  return <div className="app-shell">
    {mobileNav && <button className="nav-scrim" tabIndex={-1} aria-label="Cerrar navegación" onClick={() => setMobileNav(false)} />}
    <aside ref={navigationRef} className={`sidebar ${mobileNav ? 'is-open' : ''}`} inert={isMobile && !mobileNav} role={mobileNav ? 'dialog' : undefined} aria-modal={mobileNav ? true : undefined} aria-label={mobileNav ? 'Menú de navegación' : undefined}>
      <a className="brand" href="#hoy" onClick={e => { e.preventDefault(); navigate('today') }} aria-label="Hilo, ir a Hoy"><span className="brand-mark"><AudioLines size={29} strokeWidth={2.2} /></span><span>hilo<span className="brand-dot">.</span></span></a>
      <button className="icon-button mobile-close" aria-label="Cerrar menú" onClick={() => setMobileNav(false)}><X size={19} /></button>
      <span className="brand-tagline">TUS IDEAS, A TU RITMO</span>
      <nav aria-label="Navegación principal">{navigation.map(item => <button key={item.id} className={`nav-item ${page === item.id ? 'is-active' : ''}`} aria-current={page === item.id ? 'page' : undefined} onClick={() => navigate(item.id)}><item.icon size={20} strokeWidth={1.7} /><span>{item.label}</span>{page === item.id && <span className="nav-active-dot" />}</button>)}</nav>
      <div className="sidebar-note"><span className="little-sprout"><Sprout size={34} strokeWidth={1.4} /></span><h3>Un poquito,<br />cada día.</h3><p>Los pequeños pasos<br />también te llevan lejos.</p></div>
      <div className="sidebar-bottom"><span className="free-dot" />Siempre gratis. Siempre tuyo.<span className="version-label">HECHO PARA IR A TU RITMO</span></div>
    </aside>
    <div className="main-shell" inert={mobileNav}>
      <header className="topbar"><button ref={menuButtonRef} className="icon-button menu-button" aria-label="Abrir navegación" onClick={() => setMobileNav(true)}><Menu size={23} /></button><div className="topbar-breadcrumb">Mi espacio <ChevronRight size={13} /><span>{navigation.find(item => item.id === page)?.label}</span></div><div className="topbar-right"><span className="today-date">{formattedDate}</span><button className="icon-button settings-button" aria-label="Abrir ajustes" onClick={() => setSettingsOpen(true)}><Settings2 size={20} /></button><div className="profile-circle" aria-label="Tu espacio personal">Tú</div></div></header>
      <main id="main-content" className="main-content">
        {storageIssue && <div className="storage-notice" role="status">Este navegador no permite guardar el progreso. Podés practicar; el avance de esta visita se conservará mientras la página siga abierta.</div>}
        {page === 'today' && <>
          <div className="page-heading"><div><div className="eyebrow"><span className="tiny-sun">✳</span> UN MOMENTO PARA TI</div><h1 tabIndex={-1} ref={titleRef}>Una idea a la vez<span className="title-dot">.</span></h1><p>No hace falta tener todas las palabras. Empecemos por una.</p></div><span className="gentle-label"><Leaf size={15} /> Sin prisa. Sin presión.</span></div>
          <section className="daily-hero" aria-labelledby="daily-title"><div className="hero-copy"><span className="hero-pill"><Clock3 size={14} /> 5 minutos para conectar contigo</span><h2 id="daily-title">Tus ideas merecen<br />encontrar <em>su voz.</em></h2><p>Un poco de calma, una idea más clara y palabras<br className="desktop-break" /> que empiezan a fluir. Tu práctica de hoy te espera.</p><button className="button button-primary" onClick={startSession}>{stats.todayCompleted ? 'Volver a practicar' : 'Comenzar mi sesión'}<ArrowRight size={18} /></button><span className="hero-footnote">3 ejercicios breves · A tu ritmo</span></div><div className="hero-art"><ThreadIllustration /></div></section>
          <div className="overview-strip"><div className="overview-item"><span className="overview-icon sage"><Sprout size={21} /></span><div><span>Tu nivel actual</span><strong>{stats.level.name}<small>Nivel {stats.level.number}</small></strong></div></div><div className="overview-item"><span className="overview-icon peach"><Flame size={21} /></span><div><span>Tu constancia</span><strong>{stats.streak} {stats.streak === 1 ? 'día' : 'días'}<small>de práctica seguida</small></strong></div></div><div className="overview-item"><span className="overview-icon lavender"><Sparkles size={21} /></span><div><span>Cada práctica cuenta</span><strong>{stats.totalXp} puntos<small>ganados a tu ritmo</small></strong></div></div><button className="overview-link" onClick={() => navigate('progress')} aria-label="Ver mi progreso"><ArrowUpRight size={20} /></button></div>
          <TrainingRoute progress={progress} onStart={startExercise} />
          <div className="home-bottom-grid"><section className="suggested-section"><div className="section-heading"><div><h2>Encontrá tu hilo</h2><p>Una pequeña práctica para lo que necesitas hoy.</p></div><button className="text-button" onClick={() => navigate('exercises')}>Ver todos<ArrowRight size={15} /></button></div><div className="exercise-grid home-exercise-grid">{exercises.slice(0, 3).map(exercise => <ExerciseCard key={exercise.id} exercise={exercise} onStart={startExercise} />)}</div><div className="reassurance"><Heart size={15} /><span>No tenés que hacerlo perfecto. Estar aquí ya es un comienzo.</span></div></section><aside className="home-right"><section className="week-panel"><div className="section-heading"><h3>Tu semana, paso a paso</h3><span className="week-badge">{stats.week.filter(day => day.completed).length}/7</span></div><Week progress={progress} /><p>{stats.todayCompleted ? 'Tu práctica de hoy ya está hecha. Celebrá ese paso.' : progress.reminderEnabled ? 'Tu recordatorio de hoy: regálate unos minutos.' : 'Hoy puede ser un buen día para empezar.'}</p></section><section className="quote-preview"><span className="eyebrow"><BookOpen size={13} /> PALABRAS QUE ACOMPAÑAN</span><blockquote>“Hoy es siempre<br /><em>todavía.</em>”</blockquote><div className="quote-preview-footer"><span>Antonio Machado</span><button className="icon-button" aria-label="Explorar frases de la biblioteca" onClick={() => navigate('library')}><ArrowUpRight size={18} /></button></div></section></aside></div>
        </>}
        {page === 'exercises' && <>
          <div className="page-heading"><div><div className="eyebrow">TU CAJA DE HERRAMIENTAS</div><h1 tabIndex={-1} ref={titleRef}>Encontrá las palabras<span className="title-dot">.</span></h1><p>Elegí una práctica. Podés escribir, pensar y luego decirlo en voz alta.</p></div></div>
          <div className="exercise-banner"><span className="icon-tile peach"><AudioLines size={25} /></span><div><h3>¿No sabes por dónde empezar?</h3><p>La sesión de hoy combina expresión, memoria y calma.</p></div><button className="button button-primary" onClick={startSession}>Hacer mi sesión<ArrowRight size={17} /></button></div>
          <div className="filter-row" role="group" aria-label="Filtrar ejercicios por categoría">{(['Todos', 'Expresión', 'Pensamiento crítico', 'Vínculos', 'Dinero', 'Memoria', 'Calma'] as Category[]).map(item => <button key={item} aria-pressed={category === item} className={`filter-button ${category === item ? 'is-active' : ''}`} onClick={() => setCategory(item)}>{item}</button>)}<span>{exercises.filter(item => category === 'Todos' || item.category === category).length} ejercicios</span></div>
          <div className="exercise-grid all-exercise-grid">{exercises.filter(item => category === 'Todos' || item.category === category).map(exercise => <ExerciseCard key={exercise.id} exercise={exercise} onStart={startExercise} />)}</div><div className="practice-principle"><Leaf size={23} /><div><strong>Tu ritmo es un buen ritmo.</strong><p>Los tiempos son orientativos. Podés repetir, pausar o dejar una actividad para otro momento.</p></div></div>
        </>}
        {page === 'progress' && <>
          <div className="page-heading"><div><div className="eyebrow">CADA PASO CUENTA</div><h1 tabIndex={-1} ref={titleRef}>Mira cómo vas creciendo<span className="title-dot">.</span></h1><p>Tu progreso se construye con práctica, no con perfección.</p></div><button className="button button-outline" onClick={startSession}>Seguir practicando<ArrowRight size={17} /></button></div>
          <section className="growth-card"><div className="growth-emblem"><Sprout size={64} strokeWidth={1.3} /></div><div className="growth-content"><span className="eyebrow">NIVEL {stats.level.number}</span><h2>{stats.level.name}</h2><p>{stats.totalXp === 0 ? 'Todo empieza con una pequeña semilla. Tu primera práctica te espera.' : 'Cada vez que practicas, le das espacio a tu voz.'}</p><div className="xp-caption"><span>{stats.totalXp} puntos</span><span>{stats.level.nextXp - stats.totalXp} para el próximo nivel</span></div><div className="xp-track" role="progressbar" aria-label="Avance al siguiente nivel" aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.floor(stats.levelProgress)}><span style={{ width: `${stats.levelProgress}%` }} /></div></div></section>
          <div className="progress-stats"><div><Flame size={24} /><strong>{stats.streak}</strong><span>Días seguidos</span></div><div><CheckCircle2 size={24} /><strong>{stats.completedSessions}</strong><span>Sesiones completadas</span></div><div><Layers3 size={24} /><strong>{stats.completedExercises}</strong><span>Ejercicios practicados</span></div><div><Sparkles size={24} /><strong>{stats.totalXp}</strong><span>Puntos de práctica</span></div></div>
          <SkillsProgress progress={progress} onStart={startExercise} />
          <div className="progress-bottom"><section className="panel"><div className="section-heading"><h2>Esta semana</h2><span className="gentle-label">Un día a la vez</span></div><Week progress={progress} /><p className="muted-note">Si un día no practicas, tus puntos y tu nivel siguen contigo.</p></section><section className="panel"><div className="section-heading"><h2>Pequeños logros</h2><Trophy size={21} /></div><div className={`achievement ${stats.completedExercises > 0 ? 'unlocked' : ''}`}><span className="achievement-icon"><Sprout size={23} /></span><div><strong>El primer paso</strong><p>{stats.completedExercises > 0 ? 'Ya hiciste tu primera práctica.' : 'Completa tu primer ejercicio.'}</p></div>{stats.completedExercises > 0 && <Check size={18} />}</div><div className={`achievement ${stats.streak >= 3 ? 'unlocked' : ''}`}><span className="achievement-icon"><Flame size={23} /></span><div><strong>Encontrando tu ritmo</strong><p>Practica 3 días seguidos.</p></div>{stats.streak >= 3 && <Check size={18} />}</div><div className={`achievement ${stats.totalXp >= 100 ? 'unlocked' : ''}`}><span className="achievement-icon"><Leaf size={23} /></span><div><strong>Un nuevo brote</strong><p>Alcanza los 100 puntos.</p></div>{stats.totalXp >= 100 && <Check size={18} />}</div></section></div>
          <section className="history-section"><h2>Tu recorrido</h2>{progress.records.length === 0 ? <div className="empty-state"><span className="icon-tile sage"><Leaf size={25} /></span><h3>Tu historia empieza aquí</h3><p>Después de practicar, verás tus actividades en este espacio.</p><button className="text-button" onClick={startSession}>Dar mi primer paso<ArrowRight size={16} /></button></div> : <div className="history-list">{progress.records.slice().reverse().slice(0, 12).map(record => <div className="history-item" key={record.id}><span className="icon-tile sage">{record.mode === 'session' ? <CheckCircle2 size={20} /> : <Layers3 size={20} />}</span><div><strong>{record.mode === 'session' ? 'Sesión guiada' : exercises.find(e => e.id === record.exerciseIds[0])?.title || 'Práctica personal'}</strong><span>{new Intl.DateTimeFormat('es', { day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' }).format(new Date(record.completedAt))} · {record.exerciseIds.length} {record.exerciseIds.length === 1 ? 'ejercicio' : 'ejercicios'}</span></div><span className="history-xp">+{record.xp} puntos</span></div>)}</div>}</section>
        </>}
        {page === 'library' && <>
          <div className="page-heading"><div><div className="eyebrow">PALABRAS QUE ACOMPAÑAN</div><h1 tabIndex={-1} ref={titleRef}>Un lugar para inspirarte<span className="title-dot">.</span></h1><p>Leé despacio, encuentra una idea y exprésala con tus propias palabras.</p></div></div>
          <div className="library-intro"><span className="library-quote-mark">“</span><div><h2>Una frase puede ser un punto de partida.</h2><p>Textos de dominio público para leer, recordar y conversar contigo.</p></div><BookOpen size={36} strokeWidth={1.3} /></div>
          <div className="filter-row" role="group" aria-label="Filtrar frases"><button className={`filter-button ${!onlySaved ? 'is-active' : ''}`} aria-pressed={!onlySaved} onClick={() => setOnlySaved(false)}>Todas las frases</button><button className={`filter-button ${onlySaved ? 'is-active' : ''}`} aria-pressed={onlySaved} onClick={() => setOnlySaved(true)}><Heart size={14} /> Guardadas <span className="saved-count">{progress.savedQuoteIds.length}</span></button></div>
          <div className="library-grid">{quotes.filter(quote => !onlySaved || progress.savedQuoteIds.includes(quote.id)).map((quote, index) => <article className={`library-card library-card-${index % 3}`} key={quote.id}><div className="library-card-top"><span className="eyebrow">PARA LEER Y PENSAR</span><button className={`icon-button save-quote ${progress.savedQuoteIds.includes(quote.id) ? 'is-saved' : ''}`} aria-label={`${progress.savedQuoteIds.includes(quote.id) ? 'Quitar' : 'Guardar'} frase de ${quote.author}: ${quote.text}`} aria-pressed={progress.savedQuoteIds.includes(quote.id)} onClick={() => changeProgress(toggleSavedQuote(progress, quote.id))}><Heart size={20} fill={progress.savedQuoteIds.includes(quote.id) ? 'currentColor' : 'none'} /></button></div><blockquote>“{quote.text}”</blockquote><div className="quote-source"><strong>{quote.author}</strong><span>{quote.book}</span></div><div className="quote-prompt"><Lightbulb size={16} /><p>{quote.prompt}</p></div><button className="text-button" onClick={() => setActivePractice({ exerciseIds: [quote.id === 'camino' ? 'recuerda' : 'lectura'], mode: 'exercise', quote })}>{quote.id === 'camino' ? 'Practicar mi memoria' : 'Practicar con una lectura'}<ArrowRight size={15} /></button></article>)}</div>
          {onlySaved && progress.savedQuoteIds.length === 0 && <div className="empty-state"><span className="icon-tile peach"><Heart size={24} /></span><h3>Palabras para volver a encontrar</h3><p>Tocá el corazón de una frase y la tendrás aquí.</p><button className="text-button" onClick={() => setOnlySaved(false)}>Explorar las frases<ArrowRight size={16} /></button></div>}
          <PracticeMethods />
        </>}
        <footer className="main-footer"><span className="footer-brand">hilo.</span><p>Un espacio para tus ideas. Un momento para ti.</p><span>Gratis y sin registro.</span></footer>
      </main>
    </div>
    {activePractice && <PracticeModal exerciseIds={activePractice.exerciseIds} mode={activePractice.mode} quote={activePractice.quote} onClose={() => setActivePractice(null)} onComplete={onPracticeComplete} />}
    {settingsOpen && <SettingsDialog progress={progress} onChange={changeProgress} onClose={closeSettings} nativeAds={ads.isNativeAndroid} privacyOptionsRequired={ads.privacyOptionsRequired} privacyBusy={ads.isPrivacyBusy} privacyMessage={ads.adsStatus} onPrivacyOptions={ads.openPrivacyOptions} />}
    {notice && <div className="toast" role="status"><CheckCircle2 size={19} />{notice}<button aria-label="Cerrar aviso" onClick={() => setNotice('')}><X size={16} /></button></div>}
  </div>
}
