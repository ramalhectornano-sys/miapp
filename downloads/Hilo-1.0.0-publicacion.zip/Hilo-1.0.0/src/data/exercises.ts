import { training } from './training';

export type Exercise = {
  id: string;
  title: string;
  description: string;
  category: 'Expresión' | 'Memoria' | 'Calma' | 'Pensamiento crítico' | 'Vínculos' | 'Dinero';
  duration: number;
  xp: number;
  icon: string;
  color: 'peach' | 'sage' | 'lavender';
};

export const exercises: Exercise[] = [
  {
    id: 'ordena',
    title: 'Ordená tus ideas',
    description: 'Una idea, un detalle y un cierre. Dale un hilo a lo que querés decir.',
    category: 'Expresión',
    duration: 120,
    xp: 30,
    icon: 'layers',
    color: 'peach',
  },
  {
    id: 'recuerda',
    title: 'Palabras que quedan',
    description: 'Leé una frase breve y contala con las palabras que recuerdes.',
    category: 'Memoria',
    duration: 120,
    xp: 25,
    icon: 'spark',
    color: 'lavender',
  },
  {
    id: 'pausa',
    title: 'Una pausa para vos',
    description: 'Bajá el ritmo un momento y encontrá espacio para la próxima idea.',
    category: 'Calma',
    duration: 60,
    xp: 15,
    icon: 'leaf',
    color: 'sage',
  },
  {
    id: 'historia',
    title: 'Contá algo pequeño',
    description: 'Un momento cotidiano puede ser el comienzo de una buena historia.',
    category: 'Expresión',
    duration: 90,
    xp: 25,
    icon: 'chat',
    color: 'peach',
  },
  {
    id: 'conecta',
    title: 'Conectá tus palabras',
    description: 'Probá palabras puente para que una idea lleve a la siguiente.',
    category: 'Expresión',
    duration: 60,
    xp: 20,
    icon: 'link',
    color: 'sage',
  },
  {
    id: 'lectura',
    title: 'Leé, sentí, contá',
    description: 'Hacé tuya una frase y encontrá una manera sencilla de explicarla.',
    category: 'Memoria',
    duration: 90,
    xp: 20,
    icon: 'book',
    color: 'lavender',
  },
  ...training.map(item => ({
    id: item.id, title: item.title, description: item.method,
    category: item.category, duration: 300, xp: 35,
    icon: item.category === 'Expresión' || item.category === 'Vínculos' ? 'chat' : 'layers',
    color: (item.category === 'Dinero' ? 'sage' : item.category === 'Pensamiento crítico' ? 'lavender' : 'peach') as Exercise['color'],
  })),
];

export const sessionExerciseIds = ['ordena', 'recuerda', 'pausa'];
