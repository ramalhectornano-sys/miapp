export type GuidedExercise = {
  id: string;
  title: string;
  category: 'Expresión' | 'Pensamiento crítico' | 'Vínculos' | 'Dinero';
  method: string;
  situation: string;
  fields: { label: string; hint: string }[];
  example: string;
  review: string[];
  transfer: string;
  motivation: string;
};

// Original practice scenarios. These frameworks support practice, not diagnosis.
export const training: GuidedExercise[] = [
  {
    id: 'oracion', title: 'De palabras a una oración', category: 'Expresión',
    method: 'Quién + qué hace + un detalle. Después uní las partes y decilas sin apurarte.',
    situation: 'Querés proponer una caminata a una persona amiga. Practicá siempre esta misma situación para comparar tus intentos.',
    fields: [
      { label: '¿Quién hace algo?', hint: 'Nosotros…' },
      { label: '¿Qué acción proponés?', hint: 'podemos caminar…' },
      { label: '¿Cuándo, dónde o para qué?', hint: 'mañana por la plaza para conversar.' },
    ],
    example: 'Nosotros podemos caminar mañana por la plaza para conversar. No necesitás una frase larga para transmitir una idea.',
    review: ['Revisé quién realiza la acción.', 'Revisé que haya una acción concreta.', 'Revisé que el detalle ayude a entender.'],
    transfer: 'Hoy, antes de una conversación, pensá una oración con quién, acción y detalle. Si te trabás, retomá desde la última idea; podés hacer pausas.',
    motivation: 'Hoy practicaste cómo construir una oración. Una idea breve también merece ser escuchada.',
  },
  {
    id: 'explica', title: 'Tu idea, una razón y un ejemplo', category: 'Expresión',
    method: 'Idea → razón → ejemplo. Es un apoyo para explicar un punto de vista; un ejemplo por sí solo no prueba una afirmación.',
    situation: 'Una persona te pregunta por qué querés aprender algo nuevo. Elegí algo que te interese, como cocinar o usar una herramienta.',
    fields: [
      { label: '¿Cuál es tu idea principal?', hint: 'Quiero aprender a cocinar…' },
      { label: '¿Qué razón la sostiene?', hint: 'porque me gustaría organizar mis comidas.' },
      { label: '¿Qué ejemplo concreto podés dar?', hint: 'Por ejemplo, podría preparar un almuerzo para mañana.' },
    ],
    example: 'Quiero aprender a cocinar porque me gustaría organizar mis comidas. Por ejemplo, podría preparar un almuerzo para mañana.',
    review: ['Revisé que se entienda mi idea principal.', 'Revisé que la razón se relacione con esa idea.', 'Revisé que el ejemplo sea concreto.'],
    transfer: 'Si alguien te pregunta qué pensás, empezá con «Mi idea es…», seguí con «porque…» y cerrá con «por ejemplo…».',
    motivation: 'Le diste una estructura a lo que querés decir. Podés usarla de nuevo cuando necesites un punto de partida.',
  },
  {
    id: 'critico', title: 'Hechos, suposiciones y preguntas', category: 'Pensamiento crítico',
    method: 'Separá lo observado de tu interpretación. Buscá otra explicación y un dato que podría cambiar tu conclusión.',
    situation: 'Una persona leyó tu mensaje hace dos horas y no respondió. Tu primer pensamiento es: «Ya no le importo».',
    fields: [
      { label: '¿Qué sabés y qué estás suponiendo?', hint: 'Sé que no respondió. Estoy suponiendo el motivo…' },
      { label: '¿Qué otra explicación es posible?', hint: 'Puede estar ocupada, sin ganas de hablar o…' },
      { label: '¿Qué dato o pregunta te ayudaría a comprobarlo?', hint: 'Podría preguntar si puede hablar más tarde, sin dar el motivo por hecho.' },
    ],
    example: 'El hecho es que todavía no respondió. «No le importo» es una interpretación. Estar ocupada es otra posibilidad, no una certeza. Puedo esperar y preguntar cuándo puede hablar.',
    review: ['Separé un hecho de una interpretación.', 'Consideré otra explicación sin tratarla como certeza.', 'Elegí un dato o pregunta para comprobar mi idea.'],
    transfer: 'Ante una noticia o una conclusión rápida, preguntate: ¿qué evidencia tengo?, ¿qué falta?, ¿qué me haría cambiar de opinión?',
    motivation: 'Practicaste dejar espacio para la duda. Cambiar de opinión ante nueva evidencia también es pensar con cuidado.',
  },
  {
    id: 'vinculos', title: 'Decir lo que necesitás', category: 'Vínculos',
    method: 'Observación → emoción → necesidad → pedido concreto. Un pedido deja espacio a la respuesta de la otra persona.',
    situation: 'Alguien cercano mira el celular mientras contás algo importante. Ensayá cómo pedir atención sin insultar ni adivinar sus intenciones.',
    fields: [
      { label: '¿Qué pasó, sin etiquetas?', hint: 'Cuando mirás el celular mientras te hablo…' },
      { label: '¿Cómo te sentís y qué necesitás?', hint: 'me siento triste y necesito sentir que me escuchás.' },
      { label: '¿Qué pedido concreto podés hacer?', hint: '¿Podemos dejar los celulares cinco minutos y conversar?' },
    ],
    example: 'Cuando mirás el celular mientras te hablo, me siento triste porque necesito atención. ¿Podemos dejar los celulares cinco minutos? Si ahora no podés, acordemos otro momento.',
    review: ['Describí una conducta sin insultos ni «siempre» o «nunca».', 'Nombré una emoción y una necesidad propias.', 'Hice un pedido concreto que admite una respuesta.'],
    transfer: 'Probá con una situación pequeña y segura. No podés controlar la reacción ajena; si sentís miedo o hay maltrato, priorizá tu seguridad y buscá apoyo.',
    motivation: 'Practicaste expresar una necesidad con claridad. No tenés que encontrar palabras perfectas para merecer respeto.',
  },
  {
    id: 'escucha', title: 'Escuchar antes de responder', category: 'Vínculos',
    method: 'Resumí lo que entendiste, comprobalo con una pregunta y expresá tu posición con respeto.',
    situation: 'Una persona te dice: «Últimamente casi no tenemos tiempo para vernos y eso me pone triste».',
    fields: [
      { label: '¿Cómo resumís lo que escuchaste?', hint: 'Entiendo que extrañás pasar tiempo juntos…' },
      { label: '¿Qué pregunta abierta harías?', hint: '¿Qué momento te gustaría que compartamos?' },
      { label: '¿Cómo expresás tu posición o un límite?', hint: 'A mí también me importa vernos. Esta semana puedo…' },
    ],
    example: 'Entiendo que extrañás vernos y te sentís triste. ¿Qué te gustaría que hagamos juntos? Quiero compartir tiempo, aunque esta semana solo puedo el sábado.',
    review: ['Resumí sin decirle a la otra persona cómo debería sentirse.', 'Hice una pregunta que no se responde solo con sí o no.', 'Expresé mi posición sin prometer algo que no puedo hacer.'],
    transfer: 'En una conversación, probá «Si te entendí bien… ¿es así?». Escuchar no te obliga a estar de acuerdo ni a aceptar un pedido.',
    motivation: 'Hoy practicaste escuchar y hacerte entender. Ambas cosas pueden tener lugar en la misma conversación.',
  },
  {
    id: 'dinero', title: 'Una compra con perspectiva', category: 'Dinero',
    method: 'Disponibilidad → costo total → alternativas → decisión. Trabajá con un caso ficticio; no hace falta ingresar tus finanzas.',
    situation: 'Caso ficticio: tenés 100 unidades para la semana. Necesitás 65 para gastos básicos. Una compra cuesta 30 al contado o 3 cuotas de 12: en total, 36.',
    fields: [
      { label: '¿Cuánto queda después de lo básico?', hint: '100 − 65 = 35. Si compro al contado, quedan…' },
      { label: '¿Qué costo y alternativa compararías?', hint: '30 al contado frente a 36 en cuotas. También puedo esperar…' },
      { label: '¿Qué decidirías y qué información te falta?', hint: 'Esperaría para conservar un margen. Revisaría cargos y futuros gastos…' },
    ],
    example: 'Quedan 35 después de lo básico; comprar al contado deja 5. Las cuotas suman 36, o sea 6 más que el contado. Puedo esperar. También revisaría cargos, fechas y gastos futuros antes de decidir.',
    review: ['Revisé lo que queda luego de los gastos básicos.', 'Comparé el costo total y una alternativa, no solo la cuota.', 'Consideré el margen para imprevistos y qué datos faltan.'],
    transfer: 'Antes de una compra, compará el precio total, cargos y lo que postergás al pagarla. Es educación financiera general, no una recomendación de inversión.',
    motivation: 'Te diste tiempo para comparar. Tomar una pausa también puede ser una decisión útil.',
  },
  {
    id: 'decision', title: 'De darle vueltas a dar un paso', category: 'Pensamiento crítico',
    method: 'Definí una decisión pequeña, compará dos opciones y armá un plan «si ocurre X, haré Y».',
    situation: 'Querés retomar una actividad, pero terminás postergándola. Elegí algo pequeño y reversible: leer, ordenar un espacio o practicar una conversación.',
    fields: [
      { label: '¿Qué decisión concreta querés tomar?', hint: 'Quiero decidir cuándo leer diez minutos…' },
      { label: '¿Qué dos opciones y consecuencias comparás?', hint: 'Después del desayuno o antes de dormir. La primera…' },
      { label: '¿Cuál es tu plan y qué harás si aparece un obstáculo?', hint: 'Si termino de desayunar, leeré dos páginas. Si no puedo, probaré después de merendar.' },
    ],
    example: 'Puedo leer después del desayuno o de noche. De noche suelo estar cansado. Si termino de desayunar, leeré dos páginas. Si surge un imprevisto, lo intentaré después de merendar.',
    review: ['Elegí una decisión pequeña que depende de mí.', 'Comparé al menos dos opciones y una consecuencia de cada una.', 'Escribí una señal para actuar y una alternativa ante un obstáculo.'],
    transfer: 'Probá el paso elegido una vez. Después revisá qué ayudó y qué ajustarías. Cambiar el plan no borra lo que aprendiste.',
    motivation: 'Convertiste una idea en un paso posible. Un plan pequeño puede ajustarse cuando la vida cambia.',
  },
];

export const trainingIds = training.map(item => item.id);
