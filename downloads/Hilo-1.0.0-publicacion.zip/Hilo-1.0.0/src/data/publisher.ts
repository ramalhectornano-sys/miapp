// Public details supplied by the owner for the store listing and privacy policy.
export const publisher = {
  name: 'Ramal Hector Ruben',
  email: 'ramalhector.nano@gmail.com',
  privacyPolicyUrl: '',
  websiteUrl: '',
  policyUpdated: '9 de octubre de 2026',
};

export const privacySections = [
  {
    title: 'Responsable y contacto',
    text: `Hilo es una aplicación de práctica educativa de expresión, memoria y pensamiento crítico. Su responsable es ${publisher.name}. Para consultas de privacidad o soporte, escribí a ${publisher.email}.`,
  },
  {
    title: 'Tus ejercicios y tu progreso',
    text: 'No necesitás crear una cuenta. No grabamos audio ni pedimos acceso al micrófono, cámara, contactos o ubicación precisa. Las respuestas escritas de los ejercicios solo permanecen en memoria durante la práctica: no se guardan ni se envían. El historial de actividades, los puntos, los favoritos, el recordatorio y las valoraciones numéricas opcionales se guardan en este dispositivo. No hay un servidor de Hilo que reciba estos datos ni sincronización entre dispositivos.',
  },
  {
    title: 'Publicidad de Google y consentimiento',
    text: 'Android integra Google AdMob y User Messaging Platform (UMP) para financiar la app con un banner. Estos servicios pueden enviar a Google datos como dirección IP (que puede utilizarse para estimar una ubicación aproximada), identificadores del dispositivo o de publicidad, interacciones con anuncios e información de diagnóstico y rendimiento. Se usan para mostrar y medir publicidad, analizar su funcionamiento y prevenir fraude. Hilo no envía a Google tus respuestas, favoritos ni valoraciones. Google procesa los datos conforme a sus políticas y a tus preferencias; sus plazos de conservación y mecanismos de eliminación son independientes de los datos locales de Hilo.',
  },
  {
    title: 'Tus opciones y eliminación',
    text: 'Antes de solicitar anuncios, la app consulta UMP y muestra el formulario cuando corresponde. Solo solicita anuncios cuando el SDK indica que puede hacerlo. En Ajustes aparece el acceso a preferencias de anuncios cuando Google lo requiere. Podés borrar los datos locales desde Ajustes → Reiniciar mi progreso, borrar los datos de Hilo en Android o desinstalar la app. Reiniciar el progreso no borra datos que Google ya haya recibido. Podés consultar las opciones de privacidad y publicidad de Google y contactarnos para consultas sobre tus derechos según tu jurisdicción.',
  },
  {
    title: 'Uso de los recursos y enlaces',
    text: 'Los ejercicios son recursos educativos y no realizan diagnósticos ni ofrecen tratamiento psicológico, fonoaudiológico o asesoramiento financiero personalizado. La app puede abrir enlaces a referencias y a políticas de Google; esos sitios aplican sus propias condiciones. Esta política se actualizará si cambia el funcionamiento de Hilo. La fecha de actualización aparece junto a la política.',
  },
];
