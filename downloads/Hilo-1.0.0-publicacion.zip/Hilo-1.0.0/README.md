# Hilo

Una aplicación gratuita para ordenar ideas y practicar la expresión, la memoria y pequeñas pausas. En español, sin registro y sin servicios de pago para el usuario. La versión Android incluye un banner de AdMob para sostener la app; AdMob no muestra anuncios en la web.

## Qué incluye

- Sesión guiada de tres actividades: ordenar una idea, recordar una frase y hacer una pausa. Cinco minutos sugeridos; se puede avanzar a otro ritmo.
- Trece ejercicios individuales, sin micrófono ni grabaciones. Siete prácticas nuevas de unos cinco minutos forman una ruta libre: construir oraciones, explicar ideas, revisar suposiciones, pedir lo que necesitás, escuchar, comparar compras y planificar decisiones.
- Cada práctica nueva incluye caso, tres partes guiadas, ejemplo desplegable, ensayo con reloj opcional, revisión de estructura, motivación y un paso para aplicar fuera de Hilo.
- Seguimiento de herramientas exploradas y repeticiones. Valoraciones opcionales de claridad de 1 a 5 antes y después; la comparación usa siempre la misma situación de «De palabras a una oración» y muestra hasta cinco registros recientes. No es una medición objetiva de fluidez o mejora clínica.
- Referencias de los recursos de comunicación y aprendizaje en Biblioteca, con sus límites explícitos.
- Puntos de práctica, niveles, días de constancia, historial y logros basados en actividades realizadas. Los ejercicios que se saltan no dan puntos.
- Biblioteca de fragmentos de dominio público de Machado y Cervantes, con autor, obra, preguntas para reflexionar y favoritos.
- Exportación y reinicio del progreso desde Ajustes.
- Diseño adaptable a móvil, navegación con teclado, diálogos con control de foco y soporte de movimiento reducido.

Los puntos no evalúan inteligencia, salud ni capacidad de expresión. Hilo no realiza diagnósticos. Las respuestas de los ejercicios viven solo en memoria mientras se hace la actividad y no se guardan ni se envían. Solo se guardan las valoraciones numéricas completas de ejercicios terminados; saltar una actividad descarta sus valoraciones y no suma puntos. Editar una respuesta exige volver a ensayar y revisar. Los registros anteriores de progreso siguen siendo compatibles. El progreso y los favoritos se guardan en `localStorage` de este navegador; no se sincronizan entre dispositivos. El recordatorio opcional aparece dentro de Hilo, sin enviar notificaciones.

## Desarrollo

Requisitos: Node.js 22.12 o posterior (entorno validado con Node 24) y npm. No se necesitan credenciales para desarrollar o probar la web. Los IDs públicos de AdMob ya están configurados; los anuncios de prueba son el valor predeterminado.

Desde `/workspace/miapp`:

```sh
npm ci --cache /tmp/hilo-npm-cache --no-audit --no-fund
npm run dev -- --port 5173 --strictPort
```

El servidor escucha en todas las interfaces para el entorno de desarrollo. Los procesos deben iniciarse de nuevo en cada tarea; no se conservan al publicar una imagen del entorno. Usar el checkout existente: cada tarea cloud ya está aislada y no requiere crear un worktree.

## Validación

```sh
npm run build
npm test
npm run test:e2e
```

Las pruebas unitarias verifican almacenamiento, datos corruptos, fechas locales, rachas, niveles y validación de valoraciones opcionales. Las pruebas de navegador verifican la sesión completa, persistencia, favoritos, filtros, salida sin guardar y uso móvil, además de las siete prácticas nuevas, invalidación de revisiones al editar, comparaciones persistentes y reloj de ensayo. Playwright usa `/usr/bin/chromium`; para otro equipo, instalar Chromium con Playwright y adaptar `executablePath` en `playwright.config.ts`.

`npm run build` genera `dist/`, una aplicación estática publicable en un hosting compatible. `npm run preview -- --port 4173 --strictPort` permite comprobar ese resultado localmente. No hay backend, cuentas, reconocimiento automático del habla ni pagos.

## Estructura

- `src/App.tsx`: navegación, pantallas, favoritos y ajustes.
- `src/components/PracticeModal.tsx`: actividades y sesión guiada.
- `src/data/exercises.ts`: catálogo de actividades.
- `src/data/training.ts`: casos originales, guías, ejemplos y pasos cotidianos.
- `src/components/GuidedPractice.tsx`: ensayo, revisión y valoraciones opcionales.
- `src/components/TrainingRoute.tsx`: ruta libre y comparación personal de claridad.
- `src/components/PracticeMethods.tsx`: fuentes y límites de los métodos.
- `src/lib/progress.ts`: persistencia, calendario y niveles.
- `src/styles.css`: diseño y adaptación a pantallas pequeñas.
- `src/ads/`: consentimiento y ciclo de vida del banner nativo.
- `android/`: aplicación Android con Capacitor.
- `scripts/`: compilación y herramientas Android.
- `patches/`: corrección persistente del plugin de anuncios.

## Futuras mejoras posibles

Rotación de actividades, prácticas orales opcionales y una cuenta voluntaria para sincronizar dispositivos. Cualquier evaluación de eficacia requiere investigación específica; el avance mostrado ahora representa práctica realizada.

## Android y publicidad AdMob

La captura proporcionada identifica una aplicación y un banner **Android**, no una unidad de publicidad web. AdMob se integra a través del SDK nativo incluido en `@capacitor-community/admob`, dentro de Capacitor. Para publicidad en navegador se necesitaría una integración separada de AdSense.

IDs públicos (no son contraseñas):

- Aplicación: `ca-app-pub-4739373930169128~6642682897`, recurso `admob_app_id` y metadato `com.google.android.gms.ads.APPLICATION_ID`.
- Banner de publicación: `ca-app-pub-4739373930169128/7981007269`, en `src/ads/config.ts`.
- Paquete Android: `com.ramalhectornano.hilo`. Se debe mantener el mismo identificador al registrar/publicar esta app.

El banner es adaptable y se ubica abajo, fuera del WebView. Su altura real deja espacio en la interfaz. Se oculta en los ejercicios, ajustes y menú móvil. Un fallo al cargar deja la app utilizable y no produce reintentos continuos.

Al abrir Android se consulta UMP. Si corresponde, se presenta el formulario de consentimiento; solo se inicializan anuncios cuando `canRequestAds` permite hacerlo. Cuando Google requiere un acceso a opciones de privacidad, aparece en Ajustes. Cambiar preferencias retira anuncios cargados con las opciones anteriores. No se envían las respuestas ni el progreso a los anunciantes; el SDK de Google puede procesar datos del dispositivo y de publicidad.

### Compilar un APK de prueba

Se necesitan un **JDK 21 completo** y Android SDK 36, build-tools 35/36 y platform-tools. Ya están preparados en este entorno bajo `/workspace/.hilo-tools`. `scripts/android-env.sh` activa esas rutas y mantiene las ubicaciones que un desarrollador haya configurado. En un entorno Debian 13 limpio, `bash scripts/setup-android-cloud.sh` instala las herramientas en esa carpeta sin cambiar paquetes del sistema, verificando firmas y checksums oficiales.

```sh
npm ci --cache /tmp/hilo-npm-cache --no-audit --no-fund
npm run android:debug
```

Salida: `android/app/build/outputs/apk/debug/app-debug.apk`.

**Debug usa siempre IDs de demostración de Google**, incluso si existe una variable de modo real en el entorno. La app demo se define en `android/app/src/debug/res/values/admob.xml`; el banner demo se define en `src/ads/config.ts`. Estos anuncios no generan ingresos. Instalar el APK en un dispositivo/emulador con Internet permite comprobar el SDK y la presentación del banner; la compilación y los mocks no verifican una impresión real.

### Preparar publicación

```sh
npm run android:release
```

Este comando activa explícitamente `VITE_ADMOB_LIVE_ADS=true` para copiar los IDs de producción al paquete y genera `android/app/build/outputs/bundle/release/app-release.aab`. **El AAB queda sin la firma de publicación**: el propietario debe firmarlo con su propia clave desde Android Studio/Google Play. No hay claves de publicación en el repositorio. `npm run android:debug` vuelve a copiar recursos de prueba; hay que ejecutar nuevamente `android:release` antes de publicar para incorporar el bundle correcto. No probar anuncios reales mediante clics propios.

Para la publicación y monetización faltan las acciones de la cuenta del propietario: registrar/enlazar la app en AdMob, configurar/publicar los mensajes de privacidad correspondientes, completar su revisión y los datos de pagos de Google, y publicar una política de privacidad acorde al funcionamiento. Los IDs por sí solos no activan ingresos.

`public/app-ads.txt` contiene la declaración de este editor de Google. Si AdMob solicita verificar la app, hay que alojar ese archivo en la raíz del **sitio web del desarrollador** y enlazar ese sitio desde la ficha de la tienda. Incluirlo dentro del APK no verifica el dominio ni la cuenta; este proyecto todavía no publica ese sitio.

### Corrección del plugin

`patches/@capacitor-community+admob+8.2.1.patch` añade una comprobación de la vista dentro de la tarea de UI de `hideBanner`. El plugin comprobaba la vista antes de programar esa tarea; una carga fallida podía eliminarla entre ambos pasos y causar un cierre inesperado. `postinstall` aplica el parche con `patch-package`, después de la instalación verificada por el lockfile. Al actualizar el plugin hay que revisar esta corrección; el parche fallará explícitamente si ya no corresponde.

Pruebas de anuncios: `npm test` incluye casos de consentimiento, web sin llamadas al SDK, selección de IDs de prueba/producción, cambios de altura, ocultación/reanudación, fallos, limpieza y opciones de privacidad. Estas pruebas usan un SDK simulado; se mantiene pendiente la validación del anuncio y del consentimiento en un dispositivo real.

Fuentes: [plugin y SDK](https://github.com/capacitor-community/admob), [consentimiento](https://github.com/capacitor-community/admob/blob/main/docs/consent.md), [anuncios de prueba](https://github.com/capacitor-community/admob/blob/main/docs/testing.md), [guía Google Android](https://developers.google.com/admob/android/quick-start).

## Entrega para Google Play (1.0.0)

La versión 1.0.0 añade la política completa dentro de Ajustes y el contacto público del titular. `release/FICHA-GOOGLE-PLAY.md` contiene el texto y la relación de recursos de la tienda; `release/PUBLICACION.md` distingue el trabajo terminado de las acciones de cuenta, firma, hosting y revisión que siguen pendientes.

`npm run store:assets` regenera el icono 512 × 512, gráfico 1024 × 500, cinco capturas móviles 1080 × 1920 y el sitio de privacidad/soporte con app-ads.txt. No inventa progreso ni impresiones de anuncios para las capturas.

`npm run android:publish` es una preparación local, no una subida automática a Google. Exige la clave de carga del propietario a través de las cuatro variables `HILO_UPLOAD_*`, exige URLs HTTPS públicas confirmadas y rechaza paquetes sin firma o firmados con Android Debug. Las contraseñas y claves no van al repositorio. Sin esas variables, `android:release` continúa creando un borrador de AAB sin firmar, identificado como tal en la entrega.

La firma de las versiones APK de prueba permite actualizar esas versiones entre sí. Una futura app firmada para Play con otra clave no puede reemplazar un APK debug: Android rechazará esa actualización; instalar la versión de Play puede requerir desinstalar la versión de prueba, eliminando su progreso local.
