package com.ramalhectornano.hilo;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
