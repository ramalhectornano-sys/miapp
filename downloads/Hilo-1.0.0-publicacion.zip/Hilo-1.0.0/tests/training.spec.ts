import { test, expect, type Page } from '@playwright/test';
import { training } from '../src/data/training';

async function navigate(page: Page, name: string) {
  if (await page.getByRole('button', { name: 'Abrir navegación' }).isVisible()) {
    await page.getByRole('button', { name: 'Abrir navegación' }).click();
  }
  await page.getByRole('navigation', { name: 'Navegación principal' }).getByRole('button', { name, exact: true }).click();
}

async function fillAndReview(page: Page, id: string, before?: string, after?: string) {
  const exercise = training.find(item => item.id === id)!;
  const dialog = page.getByRole('dialog');
  const finish = dialog.getByRole('button', { name: 'Ver mi avance' });
  await expect(finish).toBeDisabled();
  if (before) await dialog.getByLabel(/^Antes de escribir:/).selectOption(before);
  for (const [index, field] of exercise.fields.entries()) {
    await dialog.getByLabel(`${index + 1}. ${field.label}`, { exact: true }).fill(`Una respuesta concreta para revisar: ${field.hint}`);
  }
  await expect(finish).toBeDisabled();
  await dialog.getByRole('checkbox', { name: 'Ensayé mi explicación, en voz alta o a mi manera' }).check();
  for (const review of exercise.review) await dialog.getByRole('checkbox', { name: review, exact: true }).check();
  if (after) await dialog.getByLabel(/^Después del ensayo:/).selectOption(after);
  await expect(finish).toBeEnabled();
  return { dialog, finish };
}

for (const exercise of training) {
  test(`${exercise.category}: ${exercise.title} can be practiced without ratings and earns only its own progress`, async ({ page }) => {
    const errors: string[] = [];
    page.on('pageerror', error => errors.push(error.message));
    await page.goto('/');
    await page.locator('.training-route').getByRole('button', { name: new RegExp(exercise.title) }).click();
    const dialog = page.getByRole('dialog');
    await expect(dialog.getByText(exercise.situation, { exact: true })).toBeVisible();
    await dialog.getByText('Ver un ejemplo y comparar', { exact: true }).click();
    await expect(dialog.getByText(exercise.example, { exact: true })).toBeVisible();
    const { finish } = await fillAndReview(page, exercise.id);
    await finish.click();
    await expect(dialog.getByText(exercise.motivation, { exact: true })).toBeVisible();
    await expect(dialog.locator('.practice-stat').filter({ hasText: 'XP ganados' })).toContainText('+35');
    await dialog.getByRole('button', { name: 'Guardar mi avance' }).click();
    await expect(page.locator('.training-route .week-badge')).toHaveText('1/7');
    await page.reload();
    await expect(page.locator('.training-route .week-badge')).toHaveText('1/7');
    const stored = await page.evaluate(() => JSON.parse(localStorage.getItem('hilo-progress-v1')!));
    expect(stored.records).toHaveLength(1);
    expect(stored.records[0].exerciseIds).toEqual([exercise.id]);
    expect(stored.records[0].assessments).toBeUndefined();
    expect(JSON.stringify(stored)).not.toContain('Una respuesta concreta');
    await navigate(page, 'Mi progreso');
    await expect(page.locator('.skills-progress')).toContainText('1 de 7 herramientas exploradas');
    expect(errors).toEqual([]);
  });
}

test('editing an explanation invalidates rehearsal and review; skipped ratings are not saved', async ({ page }) => {
  await page.goto('/');
  await page.getByRole('button', { name: 'Empezar mi ruta' }).click();
  const { dialog, finish } = await fillAndReview(page, 'oracion', '2', '4');
  await dialog.getByLabel('1. ¿Quién hace algo?', { exact: true }).fill('Mi amigo y yo');
  await expect(finish).toBeDisabled();
  await expect(dialog.getByRole('checkbox', { name: 'Ensayé mi explicación, en voz alta o a mi manera' })).not.toBeChecked();
  await expect(dialog.getByLabel(/^Después del ensayo:/)).toHaveValue('');
  await dialog.getByRole('button', { name: 'Saltar por ahora' }).click();
  await dialog.getByRole('button', { name: 'Volver al inicio' }).click();
  expect(await page.evaluate(() => localStorage.getItem('hilo-progress-v1'))).toBeNull();
  await expect(page.locator('.training-route .week-badge')).toHaveText('0/7');
});

test('repeated clarity ratings persist and compare the same situation without inflating route completion', async ({ page }) => {
  await page.goto('/');
  for (const [before, after] of [['2', '4'], ['3', '1']]) {
    await page.locator('.training-route').getByRole('button', { name: /De palabras a una oración/ }).click();
    const { dialog, finish } = await fillAndReview(page, 'oracion', before, after);
    await finish.click();
    await dialog.getByRole('button', { name: 'Guardar mi avance' }).click();
  }
  await page.reload();
  await expect(page.locator('.training-route .week-badge')).toHaveText('1/7');
  await expect(page.locator('.training-route')).toContainText('2 prácticas guardadas');
  await navigate(page, 'Mi progreso');
  await expect(page.locator('.clarity-comparison strong')).toHaveText(['2/5', '1/5']);
  await expect(page.locator('.clarity-history li')).toHaveCount(2);
  await expect(page.locator('.clarity-card')).toContainText('La última valoración es menor');
  const stored = await page.evaluate(() => JSON.parse(localStorage.getItem('hilo-progress-v1')!));
  expect(stored.records[1].assessments).toEqual([{ exerciseId: 'oracion', before: 3, after: 1 }]);
  expect(JSON.stringify(stored)).not.toContain('Una respuesta concreta');
});

test('optional rehearsal timer pauses and resumes without completing the exercise for the user', async ({ page }) => {
  await page.clock.install();
  await page.clock.pauseAt(new Date());
  await page.goto('/');
  await page.getByRole('button', { name: 'Empezar mi ruta' }).click();
  const dialog = page.getByRole('dialog');
  await dialog.getByRole('button', { name: 'Ensayar con un minuto opcional' }).click();
  await page.clock.fastForward(20_000);
  await expect(dialog.getByLabel('Tiempo de ensayo')).toHaveText('0:20');
  await dialog.getByRole('button', { name: 'Pausar ensayo' }).click();
  await page.clock.fastForward(20_000);
  await expect(dialog.getByLabel('Tiempo de ensayo')).toHaveText('0:20');
  await dialog.getByRole('button', { name: 'Ensayar con un minuto opcional' }).click();
  await page.clock.fastForward(40_000);
  await expect(dialog.getByLabel('Tiempo de ensayo')).toHaveText('1:00');
  await expect(dialog.getByRole('button', { name: 'Ver mi avance' })).toBeDisabled();
  await expect(dialog.getByRole('checkbox', { name: 'Ensayé mi explicación, en voz alta o a mi manera' })).not.toBeChecked();
});

test('the route, financial practice and skill comparison fit a narrow mobile screen', async ({ page }) => {
  await page.setViewportSize({ width: 360, height: 800 });
  await page.goto('/');
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  await page.screenshot({ path: '/tmp/hilo-artifacts/training-mobile.png', fullPage: true });
  await page.locator('.training-route').getByRole('button', { name: /Una compra con perspectiva/ }).click();
  const { dialog, finish } = await fillAndReview(page, 'dinero', '2', '3');
  expect(await dialog.evaluate(element => element.scrollWidth <= element.clientWidth + 1)).toBe(true);
  await page.screenshot({ path: '/tmp/hilo-artifacts/financial-practice-mobile.png', fullPage: true });
  await finish.click();
  await dialog.getByRole('button', { name: 'Guardar mi avance' }).click();
  await navigate(page, 'Mi progreso');
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
});
