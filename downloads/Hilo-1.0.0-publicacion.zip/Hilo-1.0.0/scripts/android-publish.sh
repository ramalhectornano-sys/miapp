#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
# A draft production bundle is available through android:release. This command
# intentionally refuses to call an unsigned or debug-signed bundle publishable.
for hilo_setting in HILO_UPLOAD_STORE_FILE HILO_UPLOAD_STORE_PASSWORD HILO_UPLOAD_KEY_ALIAS HILO_UPLOAD_KEY_PASSWORD; do
  if [ -z "${!hilo_setting:-}" ]; then
    echo "Missing $hilo_setting. The owner must supply their Play upload key outside the repository." >&2
    exit 1
  fi
done
if [ ! -f "$HILO_UPLOAD_STORE_FILE" ]; then
  echo 'The upload keystore file is missing.' >&2
  exit 1
fi
node --input-type=module - <<'JS'
import { readFileSync } from 'node:fs';
const config = readFileSync('src/data/publisher.ts', 'utf8');
for (const field of ['privacyPolicyUrl', 'websiteUrl']) {
  const value = new RegExp(`${field}: '([^']*)'`).exec(config)?.[1];
  if (!value || !value.startsWith('https://')) {
    console.error(`Set ${field} to the verified public HTTPS URL before publishing.`);
    process.exit(1);
  }
}
JS
bash scripts/android-build.sh release
source scripts/android-env.sh
hilo_bundle='android/app/build/outputs/bundle/release/app-release.aab'
python3 - "$hilo_bundle" <<'PY'
import sys, zipfile
with zipfile.ZipFile(sys.argv[1]) as bundle:
    names = bundle.namelist()
    if not any(name.startswith('META-INF/') and name.endswith(('.RSA', '.DSA', '.EC')) for name in names):
        raise SystemExit('Production bundle has no upload signature. Do not upload it to Play.')
PY
"$JAVA_HOME/bin/jarsigner" -verify "$hilo_bundle"
"$JAVA_HOME/bin/keytool" -printcert -jarfile "$hilo_bundle" > /tmp/hilo-upload-certificate.txt
if rg -q 'CN=Android Debug' /tmp/hilo-upload-certificate.txt; then
  echo 'Refusing to publish a bundle signed with an Android debug key.' >&2
  exit 1
fi
echo "Signed production bundle prepared: $hilo_bundle"
echo 'Account declarations, internal testing and approval in Play Console remain publisher actions.'
