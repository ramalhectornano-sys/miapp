#!/usr/bin/env bash
# Prefer developer-supplied locations; fall back to the prepared cloud toolchain.
hilo_tools="${HILO_TOOLCHAIN_ROOT:-/workspace/.hilo-tools}"
if [ -z "${JAVA_HOME:-}" ] && [ -x "$hilo_tools/java/usr/lib/jvm/java-21-openjdk-amd64/bin/javac" ]; then
  export JAVA_HOME="$hilo_tools/java/usr/lib/jvm/java-21-openjdk-amd64"
fi
export ANDROID_HOME="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-$hilo_tools/android-sdk}}"
export ANDROID_SDK_ROOT="${ANDROID_SDK_ROOT:-$ANDROID_HOME}"
export GRADLE_USER_HOME="${GRADLE_USER_HOME:-$hilo_tools/gradle}"
export ANDROID_USER_HOME="${ANDROID_USER_HOME:-$hilo_tools/android-user}"
if [ -n "${JAVA_HOME:-}" ]; then
  export PATH="$JAVA_HOME/bin:$ANDROID_HOME/platform-tools:$PATH"
fi

# Java/Gradle do not read HTTPS_PROXY themselves; use the platform's existing route.
# No proxy credentials are extracted or stored in the repository.
if [ -n "${HTTPS_PROXY:-}" ]; then
  hilo_proxy_flags="$(python3 - <<'PYPROXY'
import os, shlex, urllib.parse
url = urllib.parse.urlsplit(os.environ['HTTPS_PROXY'])
if url.hostname and not url.username and not url.password:
    port = url.port or (443 if url.scheme == 'https' else 80)
    flags = [f'-D{protocol}.proxyHost={url.hostname} -D{protocol}.proxyPort={port}' for protocol in ('https', 'http')]
    print(' '.join(flags))
PYPROXY
)"
  if [ -n "$hilo_proxy_flags" ]; then
    export GRADLE_OPTS="${GRADLE_OPTS:-} $hilo_proxy_flags"
  fi
fi
