#!/usr/bin/env bash
set -euo pipefail

# Install trusted Android build prerequisites without changing system packages.
TOOLS_ROOT="${HILO_TOOLCHAIN_ROOT:-/workspace/.hilo-tools}"
APT_ROOT="$TOOLS_ROOT/apt"
SDK_ROOT="$TOOLS_ROOT/android-sdk"
SDK_TOOLS_ARCHIVE="commandlinetools-linux-16111833_latest.zip"
SDK_TOOLS_SHA1="e025545c62a8e64c7559119566a569fb1dec5f60"

mkdir -p "$TOOLS_ROOT/cache" "$APT_ROOT/etc/apt.conf.d" \
  "$APT_ROOT/etc/sources.list.d" "$APT_ROOT/etc/preferences.d" "$APT_ROOT/state/lists/partial" \
  "$APT_ROOT/cache/archives/partial" "$APT_ROOT/log" "$SDK_ROOT"

cat > "$APT_ROOT/etc/sources.list" <<'SOURCES'
deb [signed-by=/usr/share/keyrings/debian-archive-keyring.gpg] https://deb.debian.org/debian trixie main
deb [signed-by=/usr/share/keyrings/debian-archive-keyring.gpg] https://deb.debian.org/debian trixie-updates main
deb [signed-by=/usr/share/keyrings/debian-archive-keyring.gpg] https://security.debian.org/debian-security trixie-security main
SOURCES

cat > "$APT_ROOT/apt.conf" <<CONFIG
Dir "$APT_ROOT";
Dir::Etc "etc";
Dir::Etc::sourcelist "sources.list";
Dir::Etc::sourceparts "sources.list.d";
Dir::Etc::main "-";
Dir::Etc::parts "apt.conf.d";
Dir::State "state";
Dir::State::status "/var/lib/dpkg/status";
Dir::State::lists "lists";
Dir::Cache "cache";
Dir::Cache::archives "archives";
Dir::Log "log";
APT::Sandbox::User "$(id -un)";
CONFIG

export APT_CONFIG="$APT_ROOT/apt.conf"
apt-get update
mkdir -p "$TOOLS_ROOT/java-packages" "$TOOLS_ROOT/java"
JAVA_PACKAGES_DIR="$(mktemp -d "$TOOLS_ROOT/java-packages/install.XXXXXX")"
(
  cd "$JAVA_PACKAGES_DIR"
  apt-get download openjdk-21-jdk-headless openjdk-21-jre-headless
  for package in ./*.deb; do
    dpkg-deb --extract "$package" "$TOOLS_ROOT/java"
  done
)

export JAVA_HOME="$TOOLS_ROOT/java/usr/lib/jvm/java-21-openjdk-amd64"
export ANDROID_HOME="$SDK_ROOT"
export ANDROID_SDK_ROOT="$SDK_ROOT"
export ANDROID_USER_HOME="$TOOLS_ROOT/android-user"
mkdir -p "$ANDROID_USER_HOME"
export PATH="$JAVA_HOME/bin:$SDK_ROOT/cmdline-tools/latest/bin:$SDK_ROOT/platform-tools:$PATH"
"$JAVA_HOME/bin/java" -version
"$JAVA_HOME/bin/javac" -version

if [[ ! -f "$TOOLS_ROOT/cache/$SDK_TOOLS_ARCHIVE" ]]; then
  curl --fail --location --show-error \
    "https://dl.google.com/android/repository/$SDK_TOOLS_ARCHIVE" \
    --output "$TOOLS_ROOT/cache/$SDK_TOOLS_ARCHIVE"
fi
printf '%s  %s\n' "$SDK_TOOLS_SHA1" "$TOOLS_ROOT/cache/$SDK_TOOLS_ARCHIVE" | sha1sum --check
if [[ ! -x "$SDK_ROOT/cmdline-tools/latest/bin/sdkmanager" ]]; then
  mkdir -p "$SDK_ROOT/cmdline-tools"
  unzip -q "$TOOLS_ROOT/cache/$SDK_TOOLS_ARCHIVE" -d "$SDK_ROOT/cmdline-tools"
  mv "$SDK_ROOT/cmdline-tools/cmdline-tools" "$SDK_ROOT/cmdline-tools/latest"
fi

# This setup is for the app's Android development and accepts Android SDK licenses.
printf 'y\n%.0s' {1..100} > "$TOOLS_ROOT/cache/android-license-answers.txt"
sdkmanager --sdk_root="$SDK_ROOT" --licenses < "$TOOLS_ROOT/cache/android-license-answers.txt"
sdkmanager --sdk_root="$SDK_ROOT" \
  'platform-tools' 'platforms;android-36' 'build-tools;35.0.0' 'build-tools;36.0.0'

cat > "$TOOLS_ROOT/env.sh" <<ENV
export JAVA_HOME="$JAVA_HOME"
export ANDROID_HOME="$SDK_ROOT"
export ANDROID_SDK_ROOT="$SDK_ROOT"
export ANDROID_USER_HOME="$ANDROID_USER_HOME"
export PATH="\$JAVA_HOME/bin:\$ANDROID_HOME/cmdline-tools/latest/bin:\$ANDROID_HOME/platform-tools:\$PATH"
ENV

sdkmanager --sdk_root="$SDK_ROOT" --list_installed
