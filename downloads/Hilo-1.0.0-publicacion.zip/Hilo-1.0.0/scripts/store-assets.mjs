import { chromium } from '@playwright/test';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { spawn } from 'node:child_process';
import { resolve } from 'node:path';

const root = resolve(import.meta.dirname, '..');
const assets = resolve(root, 'release/store');
const site = resolve(root, 'release/site');
await mkdir(assets, { recursive: true });
await mkdir(site, { recursive: true });
const publisherSource = await readFile(resolve(root, 'src/data/publisher.ts'), 'utf8');
const { publisher, privacySections } = await import(`data:text/javascript,${encodeURIComponent(publisherSource)}`);
const escape = value => value.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;');
const style = 'body{margin:0;background:#faf9f5;color:#35463b;font:16px/1.9 system-ui,sans-serif}main{max-width:820px;margin:40px auto;padding:30px}h1,h2{font-family:Georgia,serif;line-height:1.3}h1{font-size:38px}h2{font-size:25px;margin-top:35px}a{color:#a45137}footer{border-top:1px solid #ddd;padding-top:20px;margin-top:35px}';
const wrap = (title, content) => `<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escape(title)} · Hilo</title><style>${style}</style></head><body><main>${content}<footer>Hilo · ${escape(publisher.name)} · <a href="mailto:${escape(publisher.email)}">${escape(publisher.email)}</a></footer></main></body></html>`;
await writeFile(resolve(site, 'privacy.html'), wrap('Política de privacidad', `<h1>Política de privacidad de Hilo</h1><p>Actualizada: ${escape(publisher.policyUpdated)}</p>${privacySections.map(section => `<h2>${escape(section.title)}</h2><p>${escape(section.text)}</p>`).join('')}<p><a href="https://policies.google.com/privacy">Privacidad de Google</a> · <a href="https://myadcenter.google.com/">Opciones de publicidad</a></p><p><a href="index.html">Volver al sitio de Hilo</a></p>`));
await writeFile(resolve(site, 'index.html'), wrap('Tus ideas, a tu ritmo', '<h1>hilo.</h1><h2>Una idea a la vez.</h2><p>Prácticas breves para ordenar ideas, formular oraciones, recordar y pensar con cuidado. Gratis, sin registro y con progreso local.</p><p>La app Android incluye publicidad de Google para sostener el proyecto. Ofrece recursos educativos: no realiza diagnósticos ni garantiza resultados clínicos.</p><p><a href="privacy.html">Política de privacidad</a> · <a href="support.html">Soporte</a></p>'));
await writeFile(resolve(site, 'support.html'), wrap('Ayuda y contacto', `<h1>Soporte de Hilo</h1><p>Para consultas o problemas con la app, escribí a <a href="mailto:${escape(publisher.email)}">${escape(publisher.email)}</a>. No envíes contraseñas ni datos bancarios.</p><h2>¿Dónde está mi progreso?</h2><p>Se guarda en este dispositivo; no hay sincronización ni una cuenta. Borrar los datos de la app o desinstalarla elimina ese progreso.</p><h2>¿Cómo borro mis datos?</h2><p>En Hilo: Ajustes → Reiniciar mi progreso. También podés borrar los datos de Hilo desde Android. La eliminación local no borra información que los servicios de publicidad ya hayan recibido.</p><h2>¿Y los anuncios?</h2><p>Se ocultan mientras practicás. En Ajustes están las preferencias de anuncios cuando Google las requiere. Su disponibilidad depende de consentimiento, conexión y revisión de AdMob.</p><p><a href="privacy.html">Política de privacidad</a> · <a href="index.html">Inicio</a></p>`));
await writeFile(resolve(site, 'app-ads.txt'), await readFile(resolve(root, 'public/app-ads.txt')));
await writeFile(resolve(site, '.nojekyll'), '');

const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || '/usr/bin/chromium', args: ['--no-sandbox'] });
let server;
try {
  const art = await browser.newPage({ viewport: { width: 512, height: 512 }, deviceScaleFactor: 1 });
  // Original SVG matching Hilo's native icon. Rasterize without editing a photo.
  const icon = '<svg xmlns="http://www.w3.org/2000/svg" width="512" height="512" viewBox="0 0 64 64"><path fill="#E77555" d="M0 0h64v64H0z"/><path d="M18 16v32M32 16v32M46 26v22M18 32h28" fill="none" stroke="#FFF8EF" stroke-width="5" stroke-linecap="round"/><circle cx="46" cy="18" r="3" fill="#FFF8EF"/></svg>';
  await writeFile(resolve(assets, 'icon.svg'), icon);
  await art.setContent(`<style>body{margin:0}</style>${icon}`);
  await art.screenshot({ path: resolve(assets, 'icon-512.png'), omitBackground: false });
  await art.setViewportSize({ width: 1024, height: 500 });
  await art.setContent(`<style>body{margin:0;background:#f7e9dd;color:#365b4d;font-family:system-ui}main{height:500px;box-sizing:border-box;padding:60px 70px;display:flex;align-items:center;gap:65px}aside{width:205px;flex-shrink:0}aside svg{width:205px;height:205px;border-radius:42px}h1{font-size:42px;margin:0 0 25px;letter-spacing:-1px;font-weight:650}h2{font:44px/1.15 Georgia;margin:0 0 24px}p{font-size:19px;line-height:1.7;margin:0;max-width:530px}small{display:block;font-size:15px;color:#8b6955;letter-spacing:1px;margin-top:25px}</style><main><aside>${icon}</aside><section><h1>hilo.</h1><h2>Una idea a la vez.</h2><p>Practicá cómo expresarte<br>y pensar con claridad, a tu ritmo.</p><small>GRATIS · SIN REGISTRO · PRÁCTICAS BREVES</small></section></main>`);
  await art.screenshot({ path: resolve(assets, 'feature-1024x500.png') });
  await art.close();

  server = spawn(process.execPath, [resolve(root, 'node_modules/vite/bin/vite.js'), '--host', '127.0.0.1', '--port', '5175', '--strictPort'], { cwd: root, stdio: 'ignore' });
  let ready = false;
  for (let attempt = 0; attempt < 120; attempt++) {
    if (server.exitCode !== null) throw new Error('The asset preview server could not start on port 5175.');
    try { const response = await fetch('http://127.0.0.1:5175'); if (response.ok) { ready = true; break; } } catch { /* Startup not ready yet. */ }
    await new Promise(done => setTimeout(done, 250));
  }
  if (!ready) throw new Error('Timed out preparing store screenshots.');
  const page = await browser.newPage({ viewport: { width: 1080, height: 1920 }, deviceScaleFactor: 1 });
  // 1080 pixels is the raster output; 360 CSS pixels keep the actual mobile layout.
  await page.close();
  const mobile = await browser.newPage({ viewport: { width: 360, height: 640 }, deviceScaleFactor: 3 });
  await mobile.goto('http://127.0.0.1:5175');
  await mobile.screenshot({ path: resolve(assets, '01-inicio.png') });
  await mobile.locator('.training-route').scrollIntoViewIfNeeded();
  await mobile.screenshot({ path: resolve(assets, '02-ruta.png') });
  await mobile.getByRole('button', { name: 'Empezar mi ruta', exact: true }).click();
  await mobile.screenshot({ path: resolve(assets, '03-oraciones.png') });
  await mobile.getByRole('button', { name: 'Cerrar práctica' }).click();
  await mobile.getByRole('button', { name: 'Abrir navegación' }).click();
  await mobile.getByRole('navigation').getByRole('button', { name: 'Mi progreso', exact: true }).click();
  await mobile.screenshot({ path: resolve(assets, '04-progreso.png') });
  await mobile.getByRole('button', { name: 'Abrir navegación' }).click();
  await mobile.getByRole('navigation').getByRole('button', { name: 'Biblioteca', exact: true }).click();
  await mobile.screenshot({ path: resolve(assets, '05-biblioteca.png') });
  console.log('Store icon, feature graphic, five real mobile-interface captures and privacy/support site created in release/.');
} finally {
  await browser.close();
  server?.kill('SIGTERM');
}
