#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
source scripts/android-env.sh
if [ ! -x "${JAVA_HOME:-/nonexistent}/bin/javac" ]; then
  echo 'Android needs JDK 21. Set JAVA_HOME to a full JDK before building.' >&2
  exit 1
fi
if [ ! -d "$ANDROID_HOME/platforms/android-36" ]; then
  echo 'Android SDK 36 is missing. Install platforms;android-36 and build-tools;36.0.0, then set ANDROID_HOME.' >&2
  exit 1
fi
case "${1:-debug}" in
  debug)
    # Always rebuild web assets using demo ads, even if the caller exported live mode.
    VITE_ADMOB_LIVE_ADS=false npm run build
    npx cap sync android
    cd android
    ./gradlew --no-daemon --max-workers=2 assembleDebug
    ;;
  release)
    # This is an explicit production opt-in; the AAB still needs the publisher's signing key.
    VITE_ADMOB_LIVE_ADS=true npm run build
    npx cap sync android
    cd android
    ./gradlew --no-daemon --max-workers=2 bundleRelease
    ;;
  *) echo 'Usage: bash scripts/android-build.sh debug|release' >&2; exit 2 ;;
esac
