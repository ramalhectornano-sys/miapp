import type { CapacitorConfig } from '@capacitor/cli'

const config: CapacitorConfig = {
  appId: 'com.ramalhectornano.hilo',
  appName: 'Hilo',
  webDir: 'dist',
  android: {
    allowMixedContent: false,
  },
}

export default config
